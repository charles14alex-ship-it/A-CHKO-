export type AvatarTone = 'blue' | 'coral' | 'mint' | 'gold' | 'plum';

export type Comment = {
  id: string;
  authorName: string;
  username: string;
  avatarTone: AvatarTone;
  body: string;
  createdAt: string;
};

export type Post = {
  id: string;
  authorName: string;
  username: string;
  initials: string;
  avatarTone: AvatarTone;
  createdAt: string;
  body: string;
  category: string;
  imageKey?: 'creatorStory' | 'students';
  imageUri?: string;
  communityId?: string;
  communityName?: string;
  likes: number;
  liked: boolean;
  saved: boolean;
  comments: Comment[];
  commentCount: number;
};

export type Community = {
  id: string;
  name: string;
  category: string;
  description: string;
  memberCount: number;
  avatarTone: AvatarTone;
};

export type Opportunity = {
  id: string;
  title: string;
  organization: string;
  category: string;
  location: string;
  description: string;
  eligibility: string;
  sourceLabel: string;
  sourceUrl: string;
  imageKey?: 'students';
};

export type Profile = {
  name: string;
  username: string;
  bio: string;
  country: string;
  avatarTone: AvatarTone;
};

export type AppData = {
  posts: Post[];
  communities: Community[];
  opportunities: Opportunity[];
  joinedCommunityIds: string[];
  followingUsernames: string[];
  blockedUsernames: string[];
  hiddenPostIds: string[];
  reportedPostIds: string[];
  profile: Profile;
};

export const SEED_COMMUNITIES: Community[] = [
  {
    id: 'africa-creators',
    name: 'Africa Creators',
    category: 'Creative',
    description: 'A place for storytellers, makers and independent creators across Africa.',
    memberCount: 12400,
    avatarTone: 'coral',
  },
  {
    id: 'american-creators',
    name: 'American Creators',
    category: 'Creative',
    description: 'Musicians, actors and creative talent across the Americas share portfolios, sponsor leads, auditions and competitions.',
    memberCount: 0,
    avatarTone: 'blue',
  },
  {
    id: 'europe-creators',
    name: 'Europe Creators',
    category: 'Creative',
    description: 'A community for European musicians, actors and creators to share sponsorships, casting calls and open competitions.',
    memberCount: 0,
    avatarTone: 'mint',
  },
  {
    id: 'asian-creators',
    name: 'Asian Creators',
    category: 'Creative',
    description: 'Musicians, actors and talent across Asia connect around portfolios, sponsor opportunities and creative contests.',
    memberCount: 0,
    avatarTone: 'gold',
  },
  {
    id: 'international-creators',
    name: 'International Creators',
    category: 'Creative',
    description: 'A global group for musicians, actors and talented people to share sponsor leads, competitions and opportunities.',
    memberCount: 0,
    avatarTone: 'plum',
  },
  {
    id: 'entrepreneurs',
    name: 'Entrepreneurs',
    category: 'Business',
    description: 'Share what you are building and learn from people doing the work.',
    memberCount: 8300,
    avatarTone: 'gold',
  },
  {
    id: 'university-students',
    name: 'University Students',
    category: 'Education',
    description: 'Campus life, study groups and ideas for what comes after graduation.',
    memberCount: 6700,
    avatarTone: 'blue',
  },
  {
    id: 'scholarships',
    name: 'Scholarships & Fellowships',
    category: 'Scholarships',
    description: 'Share verified scholarship resources and help each other apply.',
    memberCount: 5100,
    avatarTone: 'mint',
  },
  {
    id: 'ai-technology',
    name: 'AI & Technology',
    category: 'Technology',
    description: 'Curious people exploring technology, products and practical AI.',
    memberCount: 3900,
    avatarTone: 'plum',
  },
  {
    id: 'football-fans',
    name: 'Football Fans',
    category: 'Sports',
    description: 'Match-day conversations and football from every corner of the continent.',
    memberCount: 9200,
    avatarTone: 'mint',
  },
];

export const SEED_POSTS: Post[] = [
  {
    id: 'story-neema',
    authorName: 'Neema Mushi',
    username: '@neemacreates',
    initials: 'NM',
    avatarTone: 'coral',
    createdAt: '2h',
    body: 'I started by taking photos of the pieces I was already making. My first order came from someone who had been watching quietly for weeks.',
    category: 'Business',
    imageKey: 'creatorStory',
    communityId: 'entrepreneurs',
    communityName: 'Entrepreneurs',
    likes: 2400,
    liked: false,
    saved: false,
    comments: [
      {
        id: 'comment-neema-1',
        authorName: 'Asha Juma',
        username: '@ashajuma',
        avatarTone: 'mint',
        body: 'A reminder that sharing the process matters. Thank you for this.',
        createdAt: '1h',
      },
    ],
    commentCount: 34,
  },
  {
    id: 'story-campus',
    authorName: 'Asha Juma',
    username: '@ashajuma',
    initials: 'AJ',
    avatarTone: 'mint',
    createdAt: '4h',
    body: 'The best part of campus is finding people who make room for each other. We started a Friday study circle and there is space for anyone who wants to join.',
    category: 'Education',
    imageKey: 'students',
    communityId: 'university-students',
    communityName: 'University Students',
    likes: 816,
    liked: false,
    saved: false,
    comments: [],
    commentCount: 12,
  },
  {
    id: 'story-build',
    authorName: 'Kelvin M.',
    username: '@kelvinbuilds',
    initials: 'KM',
    avatarTone: 'blue',
    createdAt: '6h',
    body: 'A useful question for anyone starting something: what is one small thing you can test with the people around you this week?',
    category: 'Business',
    communityId: 'entrepreneurs',
    communityName: 'Entrepreneurs',
    likes: 342,
    liked: false,
    saved: false,
    comments: [],
    commentCount: 8,
  },
];

export const SEED_OPPORTUNITIES: Opportunity[] = [
  {
    id: 'commonwealth-scholarships',
    title: 'Commonwealth Scholarships',
    organization: 'Commonwealth Scholarship Commission',
    category: 'Scholarships',
    location: 'Eligible Commonwealth countries',
    description:
      'Explore postgraduate scholarship programmes and check the current application round on the official scholarship site.',
    eligibility:
      'Eligibility, participating countries and deadlines vary by programme and application year. Confirm the current requirements at the source.',
    sourceLabel: 'Official scholarship site',
    sourceUrl: 'https://cscuk.fcdo.gov.uk/scholarships/',
    imageKey: 'students',
  },
  {
    id: 'un-careers',
    title: 'United Nations Careers',
    organization: 'United Nations',
    category: 'Jobs',
    location: 'Africa and international',
    description:
      'Browse current vacancies and early-career opportunities directly from the United Nations careers portal.',
    eligibility:
      'Requirements differ for each vacancy. Review the role description, location and application dates on the official portal.',
    sourceLabel: 'Official UN careers portal',
    sourceUrl: 'https://careers.un.org/',
  },
];

export const INITIAL_APP_DATA: AppData = {
  posts: SEED_POSTS,
  communities: SEED_COMMUNITIES,
  opportunities: SEED_OPPORTUNITIES,
  joinedCommunityIds: [],
  followingUsernames: [],
  blockedUsernames: [],
  hiddenPostIds: [],
  reportedPostIds: [],
  profile: {
    name: 'A-CHKO Member',
    username: '@achko_member',
    bio: 'Here to connect, share ideas and find the next opportunity.',
    country: '',
    avatarTone: 'blue',
  },
};
