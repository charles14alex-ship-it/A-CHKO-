import { Feather, Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import React, { useMemo, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { Avatar, EmptyState, IconButton, Pill } from '@/components/primitives';
import { useAppState } from '@/context/app-state';
import { useColors } from '@/hooks/useColors';

const filters = ['All', 'Posts', 'Communities', 'Opportunities'];

export default function SearchScreen() {
  const colors = useColors();
  const router = useRouter();
  const { data } = useAppState();
  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState('All');
  const term = query.trim().toLowerCase();

  const posts = useMemo(
    () =>
      data.posts.filter(
        (post) =>
          !data.hiddenPostIds.includes(post.id) &&
          !data.blockedUsernames.includes(post.username) &&
          (!term ||
            `${post.body} ${post.authorName} ${post.username} ${post.communityName ?? ''} ${post.category}`
              .toLowerCase()
              .includes(term)),
      ),
    [data.posts, data.hiddenPostIds, data.blockedUsernames, term],
  );
  const communities = useMemo(
    () =>
      data.communities.filter(
        (community) =>
          !term ||
          `${community.name} ${community.category} ${community.description}`.toLowerCase().includes(term),
      ),
    [data.communities, term],
  );
  const opportunities = useMemo(
    () =>
      data.opportunities.filter(
        (opportunity) =>
          !term ||
          `${opportunity.title} ${opportunity.category} ${opportunity.organization} ${opportunity.location}`
            .toLowerCase()
            .includes(term),
      ),
    [data.opportunities, term],
  );
  const showPosts = filter === 'All' || filter === 'Posts';
  const showCommunities = filter === 'All' || filter === 'Communities';
  const showOpportunities = filter === 'All' || filter === 'Opportunities';
  const hasResults =
    (showPosts && posts.length > 0) ||
    (showCommunities && communities.length > 0) ||
    (showOpportunities && opportunities.length > 0);

  return (
    <View style={[styles.page, { backgroundColor: colors.background }]}>
      <View style={styles.header}>
        <IconButton icon="arrow-back" label="Go back" onPress={() => router.back()} />
        <View style={[styles.searchBox, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Feather name="search" size={17} color={colors.mutedForeground} />
          <TextInput
            autoFocus
            value={query}
            onChangeText={setQuery}
            placeholder="Search people, posts, groups…"
            placeholderTextColor={colors.mutedForeground}
            accessibilityLabel="Search A-CHKO"
            testID="global-search"
            returnKeyType="search"
            style={[styles.searchInput, { color: colors.foreground }]}
          />
          {query ? (
            <IconButton icon="close-circle" label="Clear search" onPress={() => setQuery('')} size={17} color={colors.mutedForeground} />
          ) : null}
        </View>
      </View>
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.filters}
      >
        {filters.map((item) => (
          <Pill key={item} label={item} active={item === filter} onPress={() => setFilter(item)} />
        ))}
      </ScrollView>
      <ScrollView
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.results}
      >
        {!hasResults ? (
          <EmptyState
            icon="search"
            title={term ? 'No matches found' : 'Search A-CHKO'}
            description={term ? 'Try a different name or keyword.' : 'Find posts, communities and official opportunity directories.'}
          />
        ) : null}

        {showPosts && posts.length > 0 ? (
          <View style={styles.group}>
            <Text style={[styles.groupTitle, { color: colors.foreground }]}>Posts</Text>
            {posts.map((post) => (
              <Pressable
                key={post.id}
                accessibilityRole="button"
                onPress={() => router.push(`/post/${post.id}`)}
                style={({ pressed }) => [styles.resultRow, { backgroundColor: colors.card, borderColor: colors.border }, pressed && styles.pressed]}
              >
                <Avatar initials={post.initials} tone={post.avatarTone} size={40} />
                <View style={styles.resultCopy}>
                  <Text style={[styles.resultTitle, { color: colors.foreground }]} numberOfLines={1}>{post.authorName}</Text>
                  <Text style={[styles.resultDescription, { color: colors.mutedForeground }]} numberOfLines={2}>{post.body}</Text>
                </View>
                <Ionicons name="chevron-forward" size={15} color={colors.mutedForeground} />
              </Pressable>
            ))}
          </View>
        ) : null}

        {showCommunities && communities.length > 0 ? (
          <View style={styles.group}>
            <Text style={[styles.groupTitle, { color: colors.foreground }]}>Communities</Text>
            {communities.map((community) => (
              <Pressable
                key={community.id}
                accessibilityRole="button"
                onPress={() => router.push(`/community/${community.id}`)}
                style={({ pressed }) => [styles.resultRow, { backgroundColor: colors.card, borderColor: colors.border }, pressed && styles.pressed]}
              >
                <Avatar initials={community.name.slice(0, 2).toUpperCase()} tone={community.avatarTone} size={40} />
                <View style={styles.resultCopy}>
                  <Text style={[styles.resultTitle, { color: colors.foreground }]}>{community.name}</Text>
                  <Text style={[styles.resultDescription, { color: colors.mutedForeground }]} numberOfLines={1}>{community.category} · {community.description}</Text>
                </View>
                <Ionicons name="chevron-forward" size={15} color={colors.mutedForeground} />
              </Pressable>
            ))}
          </View>
        ) : null}

        {showOpportunities && opportunities.length > 0 ? (
          <View style={styles.group}>
            <Text style={[styles.groupTitle, { color: colors.foreground }]}>Opportunities</Text>
            {opportunities.map((opportunity) => (
              <Pressable
                key={opportunity.id}
                accessibilityRole="button"
                onPress={() => router.push(`/opportunity/${opportunity.id}`)}
                style={({ pressed }) => [styles.resultRow, { backgroundColor: colors.card, borderColor: colors.border }, pressed && styles.pressed]}
              >
                <View style={[styles.opportunityIcon, { backgroundColor: colors.accent }]}>
                  <Feather name={opportunity.category === 'Jobs' ? 'briefcase' : 'award'} size={18} color={colors.accentForeground} />
                </View>
                <View style={styles.resultCopy}>
                  <Text style={[styles.resultTitle, { color: colors.foreground }]}>{opportunity.title}</Text>
                  <Text style={[styles.resultDescription, { color: colors.mutedForeground }]}>{opportunity.category} · {opportunity.organization}</Text>
                </View>
                <Ionicons name="chevron-forward" size={15} color={colors.mutedForeground} />
              </Pressable>
            ))}
          </View>
        ) : null}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  page: { flex: 1, paddingTop: 12 },
  header: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingHorizontal: 17, paddingBottom: 12 },
  searchBox: { flex: 1, minHeight: 46, borderWidth: 1, borderRadius: 15, flexDirection: 'row', alignItems: 'center', gap: 8, paddingHorizontal: 11 },
  searchInput: { flex: 1, minHeight: 42, fontSize: 13 },
  filters: { gap: 8, paddingHorizontal: 17, paddingBottom: 12 },
  results: { paddingHorizontal: 17, paddingBottom: 38, gap: 22 },
  group: { gap: 9 },
  groupTitle: { fontSize: 14, fontWeight: '700', marginBottom: 1 },
  resultRow: { flexDirection: 'row', alignItems: 'center', gap: 11, borderWidth: 1, borderRadius: 17, padding: 11 },
  resultCopy: { flex: 1, gap: 4 },
  resultTitle: { fontSize: 12, fontWeight: '700' },
  resultDescription: { fontSize: 10, lineHeight: 15 },
  opportunityIcon: { width: 40, height: 40, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  pressed: { opacity: 0.72 },
});
