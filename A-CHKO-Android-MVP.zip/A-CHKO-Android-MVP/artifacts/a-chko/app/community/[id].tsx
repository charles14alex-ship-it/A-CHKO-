import { Ionicons } from '@expo/vector-icons';
import { useLocalSearchParams, useRouter } from 'expo-router';
import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { PostCard } from '@/components/post-card';
import { AppScreen, Avatar, EmptyState, IconButton, PrimaryButton, SectionHeading } from '@/components/primitives';
import { useAppState } from '@/context/app-state';
import { useColors } from '@/hooks/useColors';
import { formatCount } from '@/components/primitives';

const CREATOR_COMMUNITY_IDS = new Set([
  'american-creators',
  'europe-creators',
  'asian-creators',
  'international-creators',
]);

export default function CommunityDetailScreen() {
  const colors = useColors();
  const router = useRouter();
  const { id } = useLocalSearchParams<{ id: string }>();
  const { data, joinCommunity } = useAppState();
  const community = data.communities.find((item) => item.id === id);
  const isMember = community ? data.joinedCommunityIds.includes(community.id) : false;
  const isCreatorCommunity = community ? CREATOR_COMMUNITY_IDS.has(community.id) : false;
  const posts = data.posts.filter(
    (post) =>
      post.communityId === id &&
      !data.hiddenPostIds.includes(post.id) &&
      !data.blockedUsernames.includes(post.username),
  );

  if (!community) {
    return (
      <AppScreen>
        <IconButton icon="arrow-back" label="Go back" onPress={() => router.back()} />
        <EmptyState icon="users" title="Community not found" description="This community is no longer available on this device." />
      </AppScreen>
    );
  }

  const openCreatorComposer = () => {
    if (!isMember) joinCommunity(community.id);
    router.push({ pathname: '/(tabs)/create', params: { communityId: community.id } });
  };

  return (
    <AppScreen>
      <View style={styles.topRow}>
        <IconButton icon="arrow-back" label="Go back" onPress={() => router.back()} />
        <Text style={[styles.topTitle, { color: colors.foreground }]}>Community</Text>
      </View>

      <View style={[styles.hero, { backgroundColor: colors.heroBackground }]}>
        <View style={styles.heroTitleRow}>
          <Avatar initials={community.name.slice(0, 2).toUpperCase()} tone={community.avatarTone} size={54} />
          <View style={styles.heroTitles}>
            <Text style={[styles.name, { color: colors.heroForeground }]}>{community.name}</Text>
            <Text style={[styles.category, { color: colors.heroMuted }]}>{community.category}</Text>
          </View>
          <Ionicons name="people" size={20} color={colors.heroMuted} />
        </View>
        <Text style={[styles.description, { color: colors.heroMuted }]}>{community.description}</Text>
        <View style={styles.membersRow}>
          <Ionicons name="people-outline" size={14} color={colors.heroMuted} />
          <Text style={[styles.members, { color: colors.heroMuted }]}>{formatCount(community.memberCount)} members</Text>
        </View>
        <Pressable
          accessibilityRole="button"
          onPress={() => joinCommunity(community.id)}
          style={({ pressed }) => [
            styles.joinButton,
            { backgroundColor: isMember ? colors.secondary : colors.brandWarm },
            pressed && styles.pressed,
          ]}
        >
          <Text style={[styles.joinText, { color: isMember ? colors.foreground : colors.heroForeground }]}>
            {isMember ? 'Leave community' : 'Join community'}
          </Text>
        </Pressable>
      </View>

      {isCreatorCommunity ? (
        <View style={[styles.creatorGuide, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <View style={styles.creatorGuideHeading}>
            <View style={[styles.creatorGuideIcon, { backgroundColor: colors.accent }]}>
              <Ionicons name="megaphone-outline" size={18} color={colors.accentForeground} />
            </View>
            <Text style={[styles.creatorGuideTitle, { color: colors.foreground }]}>Creator opportunities</Text>
          </View>
          <Text style={[styles.creatorGuideBody, { color: colors.mutedForeground }]}>
            Musicians, actors and other talent can post portfolios, sponsor leads, auditions and competitions here.
            Confirm each offer with the organizer before applying.
          </Text>
          <PrimaryButton
            label={isMember ? 'Post an opportunity' : 'Join & post an opportunity'}
            icon="arrow-up-right"
            onPress={openCreatorComposer}
          />
        </View>
      ) : null}

      <SectionHeading title="Community posts" action="Create post" onAction={() => router.push('/(tabs)/create')} />
      {posts.length ? (
        <View style={styles.posts}>
          {posts.map((post) => <PostCard key={post.id} post={post} />)}
        </View>
      ) : (
        <EmptyState
          icon="message-circle"
          title="No posts yet"
          description={
            isMember
              ? 'Start the first conversation in this community.'
              : isCreatorCommunity
                ? 'Join to post a portfolio, sponsor lead, audition or competition in this group.'
                : 'Join this community to connect with its members.'
          }
          action={isMember ? 'Create a post' : undefined}
          onAction={isMember ? () => router.push('/(tabs)/create') : undefined}
        />
      )}
    </AppScreen>
  );
}

const styles = StyleSheet.create({
  topRow: { flexDirection: 'row', alignItems: 'center', gap: 9 },
  topTitle: { fontSize: 17, fontWeight: '700' },
  hero: { borderRadius: 24, padding: 19, gap: 14 },
  heroTitleRow: { flexDirection: 'row', alignItems: 'center', gap: 11 },
  heroTitles: { flex: 1, gap: 4 },
  name: { fontSize: 20, lineHeight: 25, fontWeight: '800', letterSpacing: -0.4 },
  category: { fontSize: 11, fontWeight: '600' },
  description: { fontSize: 12, lineHeight: 18 },
  membersRow: { flexDirection: 'row', alignItems: 'center', gap: 5 },
  members: { fontSize: 11 },
  joinButton: { minHeight: 43, borderRadius: 14, alignItems: 'center', justifyContent: 'center', marginTop: 2 },
  joinText: { fontSize: 12, fontWeight: '700' },
  creatorGuide: { borderWidth: 1, borderRadius: 20, padding: 15, gap: 11 },
  creatorGuideHeading: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  creatorGuideIcon: { width: 36, height: 36, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  creatorGuideTitle: { fontSize: 15, fontWeight: '800' },
  creatorGuideBody: { fontSize: 12, lineHeight: 18 },
  posts: { gap: 12 },
  pressed: { opacity: 0.72 },
});
