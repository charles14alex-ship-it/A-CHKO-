import { useRouter } from 'expo-router';
import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { PostCard } from '@/components/post-card';
import { AppScreen, EmptyState, IconButton, SectionHeading } from '@/components/primitives';
import { useAppState } from '@/context/app-state';
import { useColors } from '@/hooks/useColors';

export default function SavedScreen() {
  const colors = useColors();
  const router = useRouter();
  const { data } = useAppState();
  const posts = data.posts.filter((post) => post.saved);

  return (
    <AppScreen>
      <View style={styles.header}>
        <IconButton icon="arrow-back" label="Go back" onPress={() => router.back()} />
        <SectionHeading title="Saved posts" />
      </View>
      <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
        Keep useful ideas close for later.
      </Text>
      {posts.length ? (
        <View style={styles.posts}>
          {posts.map((post) => <PostCard key={post.id} post={post} />)}
        </View>
      ) : (
        <EmptyState
          icon="bookmark"
          title="Nothing saved yet"
          description="Tap Save on a post to keep it here."
          action="Explore the feed"
          onAction={() => router.replace('/')}
        />
      )}
    </AppScreen>
  );
}

const styles = StyleSheet.create({
  header: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  subtitle: { fontSize: 12, marginTop: -12 },
  posts: { gap: 12 },
});
