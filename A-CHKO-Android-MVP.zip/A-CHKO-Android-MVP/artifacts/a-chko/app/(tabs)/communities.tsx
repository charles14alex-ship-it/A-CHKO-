import { useRouter } from 'expo-router';
import React, { useMemo, useState } from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { CommunityCard } from '@/components/community-card';
import { AppScreen, IconButton, Pill, SectionHeading, TopBar } from '@/components/primitives';
import { useAppState } from '@/context/app-state';
import { useColors } from '@/hooks/useColors';

const categories = ['All', 'Creative', 'Business', 'Education', 'Scholarships', 'Technology', 'Sports'];

export default function CommunitiesScreen() {
  const colors = useColors();
  const router = useRouter();
  const { data } = useAppState();
  const [category, setCategory] = useState('All');
  const communities = useMemo(
    () => data.communities.filter((item) => category === 'All' || item.category === category),
    [data.communities, category],
  );
  const joinedCount = data.joinedCommunityIds.length;

  return (
    <AppScreen>
      <TopBar
        title="Communities"
        subtitle={`${joinedCount} ${joinedCount === 1 ? 'community' : 'communities'} joined`}
        right={<IconButton icon="search-outline" label="Search communities" onPress={() => router.push('/search')} />}
      />
      <View style={[styles.hero, { backgroundColor: colors.heroBackground }]}>
        <Text style={[styles.heroTitle, { color: colors.heroForeground }]}>Find your people.</Text>
        <Text style={[styles.heroDescription, { color: colors.heroMuted }]}>
          Connect with musicians, actors and creative talent. Share portfolios, sponsor leads, auditions and competitions.
        </Text>
      </View>
      <View style={styles.filterBlock}>
        <SectionHeading title="Browse by interest" />
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.filters}>
          {categories.map((item) => (
            <Pill key={item} label={item} active={item === category} onPress={() => setCategory(item)} />
          ))}
        </ScrollView>
      </View>
      <View style={styles.list}>
        {communities.map((community) => (
          <CommunityCard key={community.id} community={community} />
        ))}
      </View>
      <View style={[styles.note, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <Text style={[styles.noteTitle, { color: colors.foreground }]}>Community roles</Text>
        <Text style={[styles.noteBody, { color: colors.mutedForeground }]}>
          Community leaders can guide conversations, welcome members and share useful resources.
        </Text>
      </View>
    </AppScreen>
  );
}

const styles = StyleSheet.create({
  hero: { minHeight: 118, borderRadius: 22, justifyContent: 'center', padding: 20, gap: 7 },
  heroTitle: { fontSize: 22, fontWeight: '800', letterSpacing: -0.5 },
  heroDescription: { fontSize: 12, lineHeight: 18, maxWidth: 270 },
  filterBlock: { gap: 12 },
  filters: { gap: 8 },
  list: { gap: 10 },
  note: { borderWidth: 1, borderRadius: 19, padding: 16, gap: 6 },
  noteTitle: { fontSize: 13, fontWeight: '700' },
  noteBody: { fontSize: 11, lineHeight: 17 },
});
