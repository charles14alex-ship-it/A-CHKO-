import { Feather } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useRouter } from 'expo-router';
import React, { useMemo, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { CommunityCard } from '@/components/community-card';
import { OpportunityCard } from '@/components/opportunity-card';
import {
  AppScreen,
  EmptyState,
  IconButton,
  Pill,
  SectionHeading,
  TopBar,
} from '@/components/primitives';
import { useAppState } from '@/context/app-state';
import { useColors } from '@/hooks/useColors';

const filters = ['All', 'Scholarships', 'Jobs', 'Business', 'Creative', 'Technology', 'Education', 'Sports'];

export default function DiscoverScreen() {
  const colors = useColors();
  const router = useRouter();
  const { data } = useAppState();
  const [selectedFilter, setSelectedFilter] = useState('All');
  const opportunities = useMemo(
    () =>
      data.opportunities.filter(
        (item) => selectedFilter === 'All' || item.category === selectedFilter,
      ),
    [data.opportunities, selectedFilter],
  );
  const communities = useMemo(
    () =>
      data.communities.filter(
        (item) => selectedFilter === 'All' || item.category === selectedFilter,
      ),
    [data.communities, selectedFilter],
  );

  return (
    <AppScreen>
      <TopBar
        title="Discover"
        subtitle="Find people, communities and your next opportunity."
        right={<IconButton icon="search-outline" label="Search A-CHKO" onPress={() => router.push('/search')} />}
      />

      <LinearGradient
        colors={[colors.heroBackground, colors.heroAccent]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={styles.feature}
      >
        <View style={styles.featureCopy}>
          <Text style={[styles.featureEyebrow, { color: colors.heroMuted }]}>OPPORTUNITY HUB</Text>
          <Text style={[styles.featureTitle, { color: colors.heroForeground }]}>
            Your next step starts here.
          </Text>
          <Text style={[styles.featureBody, { color: colors.heroMuted }]}>
            Explore official scholarship and career directories.
          </Text>
        </View>
        <View style={styles.featureIcon}>
          <Feather name="arrow-up-right" size={19} color={colors.heroForeground} />
        </View>
      </LinearGradient>

      <View style={styles.filterBlock}>
        <SectionHeading title="Explore by interest" />
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.filters}>
          {filters.map((filter) => (
            <Pill
              key={filter}
              label={filter}
              active={filter === selectedFilter}
              onPress={() => setSelectedFilter(filter)}
              testID={`discover-filter-${filter.toLowerCase()}`}
            />
          ))}
        </ScrollView>
      </View>

      <View style={styles.section}>
        <SectionHeading
          title="Opportunities"
          action="See all"
          onAction={() => setSelectedFilter('All')}
        />
        {opportunities.length ? (
          opportunities.map((opportunity) => (
            <OpportunityCard key={opportunity.id} opportunity={opportunity} />
          ))
        ) : (
          <EmptyState
            icon="search"
            title={`No ${selectedFilter.toLowerCase()} listings yet`}
            description="Try another interest, or check back as new official sources are added."
          />
        )}
        <Text style={[styles.sourceNote, { color: colors.mutedForeground }]}>
          Listings link to official directories. Always confirm dates and eligibility at the source.
        </Text>
      </View>

      <View style={styles.section}>
        <SectionHeading title={selectedFilter === 'All' ? 'Communities to explore' : `${selectedFilter} communities`} />
        {communities.length ? (
          communities.map((community) => (
            <CommunityCard key={community.id} community={community} />
          ))
        ) : (
          <EmptyState
            icon="users"
            title="No communities in this category yet"
            description="Choose another interest to find a group to join."
          />
        )}
      </View>

      <Pressable
        accessibilityRole="button"
        onPress={() => router.push('/communities')}
        style={({ pressed }) => [styles.allCommunities, { borderColor: colors.border }, pressed && styles.pressed]}
      >
        <Text style={[styles.allCommunitiesText, { color: colors.foreground }]}>Browse all communities</Text>
        <Feather name="arrow-right" size={16} color={colors.foreground} />
      </Pressable>
    </AppScreen>
  );
}

const styles = StyleSheet.create({
  feature: { minHeight: 158, borderRadius: 24, padding: 21, flexDirection: 'row', alignItems: 'flex-end', justifyContent: 'space-between', overflow: 'hidden' },
  featureCopy: { flex: 1, maxWidth: 260, gap: 8 },
  featureEyebrow: { fontSize: 9, fontWeight: '800', letterSpacing: 1.3 },
  featureTitle: { fontSize: 23, lineHeight: 28, fontWeight: '800', letterSpacing: -0.7 },
  featureBody: { fontSize: 12, lineHeight: 17 },
  featureIcon: { width: 35, height: 35, borderRadius: 13, borderWidth: 1, borderColor: 'rgba(255,255,255,0.24)', alignItems: 'center', justifyContent: 'center' },
  filterBlock: { gap: 12 },
  filters: { gap: 8, paddingRight: 18 },
  section: { gap: 11 },
  sourceNote: { fontSize: 10, lineHeight: 15, marginTop: -3 },
  allCommunities: { minHeight: 48, borderWidth: 1, borderRadius: 16, paddingHorizontal: 15, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  allCommunitiesText: { fontSize: 13, fontWeight: '700' },
  pressed: { opacity: 0.72 },
});
