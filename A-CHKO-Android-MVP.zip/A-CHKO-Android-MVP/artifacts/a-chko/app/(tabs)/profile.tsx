import { Feather, Ionicons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { useRouter } from 'expo-router';
import React from 'react';
import { Pressable, Share, StyleSheet, Text, View } from 'react-native';
import { CommunityCard } from '@/components/community-card';
import { AppScreen, Avatar, IconButton, SectionHeading, TopBar } from '@/components/primitives';
import { useAppState } from '@/context/app-state';
import { useColors } from '@/hooks/useColors';

export default function ProfileScreen() {
  const colors = useColors();
  const router = useRouter();
  const { data } = useAppState();
  const initials = data.profile.name
    .split(/\s+/)
    .map((part) => part[0] ?? '')
    .join('')
    .slice(0, 2)
    .toUpperCase();
  const ownPosts = data.posts.filter((post) => post.username === data.profile.username);
  const joinedCommunities = data.communities.filter((community) =>
    data.joinedCommunityIds.includes(community.id),
  );

  return (
    <AppScreen>
      <TopBar
        title="Profile"
        right={<IconButton icon="settings-outline" label="Edit profile" onPress={() => router.push('/profile/edit')} />}
      />

      <View style={styles.profileHead}>
        <View style={styles.avatarWrap}>
          <Avatar initials={initials || 'A'} tone={data.profile.avatarTone} size={84} />
          <View style={[styles.onlineDot, { backgroundColor: colors.brandMint, borderColor: colors.background }]} />
        </View>
        <Text style={[styles.name, { color: colors.foreground }]}>{data.profile.name}</Text>
        <Text style={[styles.username, { color: colors.mutedForeground }]}>{data.profile.username}</Text>
        {data.profile.country ? (
          <View style={styles.location}>
            <Ionicons name="location-outline" size={13} color={colors.mutedForeground} />
            <Text style={[styles.locationText, { color: colors.mutedForeground }]}>{data.profile.country}</Text>
          </View>
        ) : null}
        <Text style={[styles.bio, { color: colors.foreground }]}>{data.profile.bio}</Text>
        <View style={styles.profileActions}>
          <Pressable
            accessibilityRole="button"
            onPress={() => router.push('/profile/edit')}
            style={({ pressed }) => [styles.editButton, { backgroundColor: colors.foreground }, pressed && styles.pressed]}
          >
            <Text style={[styles.editButtonText, { color: colors.background }]}>Edit profile</Text>
          </Pressable>
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Share profile"
            onPress={() => {
              void Haptics.selectionAsync();
              void Share.share({ message: `Connect with ${data.profile.name} on A-CHKO.` });
            }}
            style={({ pressed }) => [styles.shareButton, { borderColor: colors.border }, pressed && styles.pressed]}
          >
            <Feather name="share-2" size={17} color={colors.foreground} />
          </Pressable>
        </View>
      </View>

      <View style={[styles.stats, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <Stat label="Posts" value={ownPosts.length} />
        <View style={[styles.statDivider, { backgroundColor: colors.border }]} />
        <Stat label="Following" value={data.followingUsernames.length} />
        <View style={[styles.statDivider, { backgroundColor: colors.border }]} />
        <Stat label="Communities" value={joinedCommunities.length} />
      </View>

      <Pressable
        accessibilityRole="button"
        onPress={() => router.push('/saved')}
        style={({ pressed }) => [styles.savedRow, { backgroundColor: colors.accent }, pressed && styles.pressed]}
      >
        <View style={[styles.savedIcon, { backgroundColor: colors.background }]}>
          <Ionicons name="bookmark-outline" size={18} color={colors.brandBlue} />
        </View>
        <View style={styles.savedText}>
          <Text style={[styles.savedTitle, { color: colors.foreground }]}>Saved posts</Text>
          <Text style={[styles.savedCaption, { color: colors.mutedForeground }]}>
            {data.posts.filter((post) => post.saved).length} items saved for later
          </Text>
        </View>
        <Ionicons name="chevron-forward" size={17} color={colors.mutedForeground} />
      </Pressable>

      <View style={styles.section}>
        <SectionHeading
          title="Your communities"
          action="Explore"
          onAction={() => router.push('/communities')}
        />
        {joinedCommunities.length ? (
          joinedCommunities.map((community) => (
            <CommunityCard key={community.id} community={community} />
          ))
        ) : (
          <Pressable
            accessibilityRole="button"
            onPress={() => router.push('/communities')}
            style={({ pressed }) => [styles.joinPrompt, { backgroundColor: colors.card, borderColor: colors.border }, pressed && styles.pressed]}
          >
            <Ionicons name="people-outline" size={20} color={colors.brandBlue} />
            <Text style={[styles.joinPromptText, { color: colors.foreground }]}>
              Find a community that fits you
            </Text>
            <Ionicons name="arrow-forward" size={16} color={colors.mutedForeground} />
          </Pressable>
        )}
      </View>

      <View style={styles.section}>
        <SectionHeading title="Your posts" />
        {ownPosts.length ? (
          ownPosts.map((post) => (
            <Pressable
              key={post.id}
              accessibilityRole="button"
              onPress={() => router.push(`/post/${post.id}`)}
              style={({ pressed }) => [styles.ownPost, { backgroundColor: colors.card, borderColor: colors.border }, pressed && styles.pressed]}
            >
              <Text style={[styles.ownPostText, { color: colors.foreground }]} numberOfLines={3}>
                {post.body}
              </Text>
              <Text style={[styles.ownPostMeta, { color: colors.mutedForeground }]}>
                {post.createdAt} · {post.likes} likes · {post.commentCount} comments
              </Text>
            </Pressable>
          ))
        ) : (
          <Pressable
            accessibilityRole="button"
            onPress={() => router.push('/(tabs)/create')}
            style={({ pressed }) => [styles.joinPrompt, { backgroundColor: colors.card, borderColor: colors.border }, pressed && styles.pressed]}
          >
            <Feather name="edit-3" size={17} color={colors.brandBlue} />
            <Text style={[styles.joinPromptText, { color: colors.foreground }]}>Share your first post</Text>
            <Ionicons name="arrow-forward" size={16} color={colors.mutedForeground} />
          </Pressable>
        )}
      </View>
    </AppScreen>
  );
}

function Stat({ label, value }: { label: string; value: number }) {
  const colors = useColors();
  return (
    <View style={styles.stat}>
      <Text style={[styles.statValue, { color: colors.foreground }]}>{value}</Text>
      <Text style={[styles.statLabel, { color: colors.mutedForeground }]}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  profileHead: { alignItems: 'center', gap: 7, paddingTop: 5 },
  avatarWrap: { position: 'relative', marginBottom: 4 },
  onlineDot: { position: 'absolute', bottom: 3, right: 1, width: 16, height: 16, borderRadius: 8, borderWidth: 3 },
  name: { fontSize: 21, fontWeight: '800', letterSpacing: -0.3 },
  username: { fontSize: 12 },
  location: { flexDirection: 'row', alignItems: 'center', gap: 3 },
  locationText: { fontSize: 11 },
  bio: { maxWidth: 290, textAlign: 'center', fontSize: 13, lineHeight: 20, marginTop: 4 },
  profileActions: { flexDirection: 'row', alignItems: 'center', gap: 9, marginTop: 7 },
  editButton: { paddingHorizontal: 23, minHeight: 42, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  editButtonText: { fontSize: 12, fontWeight: '700' },
  shareButton: { width: 42, height: 42, borderRadius: 14, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  stats: { flexDirection: 'row', alignItems: 'center', borderWidth: 1, borderRadius: 20, paddingVertical: 15 },
  stat: { flex: 1, alignItems: 'center', gap: 4 },
  statValue: { fontSize: 18, fontWeight: '800' },
  statLabel: { fontSize: 10, fontWeight: '500' },
  statDivider: { width: StyleSheet.hairlineWidth, height: 30 },
  savedRow: { minHeight: 66, flexDirection: 'row', alignItems: 'center', gap: 12, padding: 12, borderRadius: 18 },
  savedIcon: { width: 38, height: 38, borderRadius: 13, alignItems: 'center', justifyContent: 'center' },
  savedText: { flex: 1, gap: 3 },
  savedTitle: { fontSize: 12, fontWeight: '700' },
  savedCaption: { fontSize: 10 },
  section: { gap: 11 },
  joinPrompt: { minHeight: 56, flexDirection: 'row', alignItems: 'center', gap: 10, paddingHorizontal: 14, borderWidth: 1, borderRadius: 18 },
  joinPromptText: { flex: 1, fontSize: 12, fontWeight: '600' },
  ownPost: { borderWidth: 1, borderRadius: 18, padding: 15, gap: 10 },
  ownPostText: { fontSize: 13, lineHeight: 19 },
  ownPostMeta: { fontSize: 10 },
  pressed: { opacity: 0.75 },
});
