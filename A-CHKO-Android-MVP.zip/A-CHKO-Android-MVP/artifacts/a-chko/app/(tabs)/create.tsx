import { Feather, Ionicons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import * as ImagePicker from 'expo-image-picker';
import { useLocalSearchParams, useRouter } from 'expo-router';
import React, { useState } from 'react';
import {
  Alert,
  Image,
  Linking,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { KeyboardAvoidingView } from 'react-native-keyboard-controller';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useAppState } from '@/context/app-state';
import { useColors } from '@/hooks/useColors';
import { Avatar, Pill, PrimaryButton } from '@/components/primitives';

export default function CreateScreen() {
  const { communityId: requestedCommunityId } = useLocalSearchParams<{ communityId?: string | string[] }>();
  const initialCommunityId = Array.isArray(requestedCommunityId) ? requestedCommunityId[0] : requestedCommunityId;

  return <CreateComposer key={initialCommunityId ?? 'general'} initialCommunityId={initialCommunityId} />;
}

function CreateComposer({ initialCommunityId }: { initialCommunityId?: string }) {
  const colors = useColors();
  const router = useRouter();
  const { data, createPost, joinCommunity } = useAppState();
  const [body, setBody] = useState('');
  const [imageUri, setImageUri] = useState<string | undefined>();
  const [communityId, setCommunityId] = useState<string | undefined>(initialCommunityId);
  const selectedCommunity = data.communities.find((community) => community.id === communityId);

  const choosePhoto = async () => {
    const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permission.granted) {
      Alert.alert(
        'Photo access needed',
        'Allow photo access to add an image to your post. You can also publish a text post without a photo.',
        [
          { text: 'Not now', style: 'cancel' },
          ...(permission.canAskAgain || Platform.OS === 'web'
            ? []
            : [{ text: 'Open settings', onPress: () => void Linking.openSettings() }]),
        ],
      );
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ['images'],
      allowsEditing: true,
      quality: 0.85,
    });
    if (!result.canceled && result.assets[0]) setImageUri(result.assets[0].uri);
  };

  const publish = () => {
    if (!body.trim() && !imageUri) {
      Alert.alert('Add something to share', 'Write a post or choose a photo before publishing.');
      return;
    }
    if (communityId && !data.joinedCommunityIds.includes(communityId)) joinCommunity(communityId);
    createPost(body, imageUri, communityId);
    void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    setBody('');
    setImageUri(undefined);
    setCommunityId(undefined);
    router.navigate('/');
  };

  return (
    <SafeAreaView edges={['top']} style={[styles.safeArea, { backgroundColor: colors.background }]}>
      <KeyboardAvoidingView
        style={styles.flex}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={0}
      >
        <ScrollView
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
          contentContainerStyle={[
            styles.content,
            { paddingTop: Platform.OS === 'web' ? 67 : 8, paddingBottom: Platform.OS === 'web' ? 120 : 112 },
          ]}
        >
          <View style={styles.header}>
            <View>
              <Text style={[styles.title, { color: colors.foreground }]}>Create</Text>
              <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>Share something worth passing on.</Text>
            </View>
            <PrimaryButton label="Post" onPress={publish} icon="arrow-up-right" testID="publish-post" />
          </View>

          <View style={[styles.composer, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <View style={styles.authorRow}>
              <Avatar initials={data.profile.name.split(/\s+/).map((part) => part[0] ?? '').join('').slice(0, 2).toUpperCase()} tone={data.profile.avatarTone} size={42} />
              <View style={styles.authorMeta}>
                <Text style={[styles.authorName, { color: colors.foreground }]}>{data.profile.name}</Text>
                <Text style={[styles.authorAudience, { color: colors.mutedForeground }]}>
                  {selectedCommunity ? `Posting in ${selectedCommunity.name}` : 'Sharing with the A-CHKO community'}
                </Text>
              </View>
            </View>
            <TextInput
              value={body}
              onChangeText={setBody}
              multiline
              maxLength={1200}
              placeholder={
                selectedCommunity?.id.endsWith('-creators')
                  ? 'Share a portfolio, sponsor lead, audition, competition or opportunity...'
                  : 'What are you learning, making or looking for?'
              }
              placeholderTextColor={colors.mutedForeground}
              textAlignVertical="top"
              accessibilityLabel="Post text"
              testID="post-text-input"
              style={[styles.input, { color: colors.foreground }]}
            />
            {imageUri ? (
              <View>
                <Image source={{ uri: imageUri }} style={styles.previewImage} />
                <Pressable
                  accessibilityRole="button"
                  accessibilityLabel="Remove photo"
                  onPress={() => setImageUri(undefined)}
                  style={[styles.removePhoto, { backgroundColor: colors.foreground }]}
                >
                  <Ionicons name="close" size={17} color={colors.background} />
                </Pressable>
              </View>
            ) : null}
            <Text style={[styles.characterCount, { color: colors.mutedForeground }]}>{body.length}/1200</Text>
          </View>

          <View style={styles.optionRow}>
            <Pressable
              accessibilityRole="button"
              onPress={() => void choosePhoto()}
              style={({ pressed }) => [styles.option, { backgroundColor: colors.card, borderColor: colors.border }, pressed && styles.pressed]}
            >
              <Feather name="image" size={18} color={colors.brandBlue} />
              <Text style={[styles.optionText, { color: colors.foreground }]}>Add a photo</Text>
            </Pressable>
          </View>

          <View style={styles.communities}>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Share to a community</Text>
            <Text style={[styles.sectionHint, { color: colors.mutedForeground }]}>
              {selectedCommunity ? 'This post will appear in the selected group.' : 'Optional. Choose a group to connect this post to.'}
            </Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.pillList}>
              {data.communities
                .filter((community) => data.joinedCommunityIds.includes(community.id) || community.id === communityId)
                .map((community) => (
                  <Pill
                    key={community.id}
                    label={community.name}
                    active={community.id === communityId}
                    onPress={() => setCommunityId(community.id === communityId ? undefined : community.id)}
                  />
                ))}
              {!data.joinedCommunityIds.length && !communityId ? (
                <Text style={[styles.noCommunities, { color: colors.mutedForeground }]}>
                  Join a community first, or publish to your feed.
                </Text>
              ) : null}
            </ScrollView>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  safeArea: { flex: 1 },
  content: { paddingHorizontal: 18, gap: 20 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', gap: 12 },
  title: { fontSize: 25, fontWeight: '800', letterSpacing: -0.6 },
  subtitle: { fontSize: 12, marginTop: 3 },
  composer: { borderWidth: 1, borderRadius: 22, padding: 16, gap: 15 },
  authorRow: { flexDirection: 'row', alignItems: 'center', gap: 11 },
  authorMeta: { flex: 1, gap: 3 },
  authorName: { fontSize: 14, fontWeight: '700' },
  authorAudience: { fontSize: 11 },
  input: { minHeight: 150, fontSize: 16, lineHeight: 23, padding: 0 },
  previewImage: { width: '100%', height: 220, borderRadius: 16 },
  removePhoto: { position: 'absolute', top: 10, right: 10, width: 30, height: 30, borderRadius: 15, alignItems: 'center', justifyContent: 'center' },
  characterCount: { alignSelf: 'flex-end', fontSize: 10 },
  optionRow: { flexDirection: 'row', gap: 10 },
  option: { minHeight: 48, flexDirection: 'row', alignItems: 'center', gap: 9, paddingHorizontal: 15, borderRadius: 15, borderWidth: 1 },
  optionText: { fontSize: 12, fontWeight: '600' },
  communities: { gap: 8 },
  sectionTitle: { fontSize: 16, fontWeight: '700' },
  sectionHint: { fontSize: 12, lineHeight: 17 },
  pillList: { gap: 8, paddingVertical: 3 },
  noCommunities: { fontSize: 12, lineHeight: 18, paddingVertical: 8 },
  pressed: { opacity: 0.72 },
});
