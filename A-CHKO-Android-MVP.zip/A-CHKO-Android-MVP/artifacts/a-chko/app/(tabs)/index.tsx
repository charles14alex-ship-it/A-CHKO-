import { useRouter } from 'expo-router';
import React, { useMemo, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { PostCard } from '@/components/post-card';
import {
  AppScreen,
  Avatar,
  BrandMark,
  EmptyState,
  IconButton,
  LoadingState,
  Pill,
  SectionHeading,
} from '@/components/primitives';
import { useAppState } from '@/context/app-state';
import { useColors } from '@/hooks/useColors';

type FeedMode = 'For you' | 'Following';

export default function HomeScreen() {
  const colors = useColors();
  const router = useRouter();
  const { data, isReady, storageError } = useAppState();
  const [feedMode, setFeedMode] = useState<FeedMode>('For you');
  const posts = useMemo(
    () =>
      data.posts.filter((post) => {
        if (data.hiddenPostIds.includes(post.id)) return false;
        if (data.blockedUsernames.includes(post.username)) return false;
        return feedMode === 'For you' || data.followingUsernames.includes(post.username);
      }),
    [data.posts, data.hiddenPostIds, data.blockedUsernames, data.followingUsernames, feedMode],
  );
  const initials = data.profile.name
    .split(/\s+/)
    .map((part) => part[0] ?? '')
    .join('')
    .slice(0, 2)
    .toUpperCase();

  if (!isReady) {
    return (
      <AppScreen>
        <LoadingState />
      </AppScreen>
    );
  }

  return (
    <AppScreen>
      <View style={styles.header}>
        <BrandMark />
        <View style={styles.headerActions}>
          <IconButton icon="search-outline" label="Search A-CHKO" onPress={() => router.push('/search')} />
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Open profile"
            onPress={() => router.push('/(tabs)/profile')}
            style={({ pressed }) => pressed && styles.pressed}
          >
            <Avatar initials={initials || 'A'} tone={data.profile.avatarTone} size={36} />
          </Pressable>
        </View>
      </View>

      {storageError ? (
        <View style={[styles.storageBanner, { backgroundColor: colors.warningSurface }]}>
          <Text style={[styles.storageText, { color: colors.warning }]}>{storageError}</Text>
        </View>
      ) : null}

      <View style={[styles.welcomeCard, { backgroundColor: colors.heroBackground }]}>
        <View style={styles.welcomeCopy}>
          <Text style={[styles.welcomeEyebrow, { color: colors.heroMuted }]}>YOUR WORLD, IN ONE PLACE</Text>
          <Text style={[styles.welcomeTitle, { color: colors.heroForeground }]}>Watch. Connect. Discover.</Text>
          <Text style={[styles.welcomeBody, { color: colors.heroMuted }]}>
            Ideas to watch. People to meet. Opportunities to find.
          </Text>
        </View>
        <Pressable
          accessibilityRole="button"
          onPress={() => router.push('/(tabs)/discover')}
          style={({ pressed }) => [
            styles.discoverButton,
            { backgroundColor: colors.brandWarm },
            pressed && styles.pressed,
          ]}
        >
          <Text style={[styles.discoverButtonText, { color: colors.heroForeground }]}>Discover</Text>
        </Pressable>
        <View style={[styles.orbitOne, { borderColor: colors.heroOrbit }]} />
        <View style={[styles.orbitTwo, { borderColor: colors.heroOrbit }]} />
      </View>

      <View style={styles.feedHeading}>
        <SectionHeading title="Your feed" />
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.feedFilters}>
          {(['For you', 'Following'] as FeedMode[]).map((mode) => (
            <Pill
              key={mode}
              label={mode}
              active={feedMode === mode}
              onPress={() => setFeedMode(mode)}
              testID={`feed-${mode.toLowerCase().replace(' ', '-')}`}
            />
          ))}
        </ScrollView>
      </View>

      {posts.length ? (
        <View style={styles.posts}>
          {posts.map((post) => <PostCard key={post.id} post={post} />)}
        </View>
      ) : (
        <EmptyState
          icon={feedMode === 'Following' ? 'user-plus' : 'activity'}
          title={feedMode === 'Following' ? 'Your following feed is quiet' : 'Your feed is ready'}
          description={
            feedMode === 'Following'
              ? 'Follow creators from a post to see their updates here.'
              : 'Explore communities and opportunities to find posts for you.'
          }
          action="Explore"
          onAction={() => router.push('/(tabs)/discover')}
        />
      )}
    </AppScreen>
  );
}

const styles = StyleSheet.create({
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', minHeight: 46 },
  headerActions: { flexDirection: 'row', alignItems: 'center', gap: 14 },
  welcomeCard: { minHeight: 188, borderRadius: 25, padding: 20, overflow: 'hidden', justifyContent: 'space-between' },
  welcomeCopy: { gap: 8, maxWidth: 260, zIndex: 1 },
  welcomeEyebrow: { fontSize: 9, letterSpacing: 1.3, fontWeight: '800' },
  welcomeTitle: { fontSize: 24, lineHeight: 29, letterSpacing: -0.8, fontWeight: '800' },
  welcomeBody: { maxWidth: 235, fontSize: 12, lineHeight: 18 },
  discoverButton: { zIndex: 1, alignSelf: 'flex-start', minHeight: 38, borderRadius: 13, paddingHorizontal: 15, justifyContent: 'center', marginTop: 15 },
  discoverButtonText: { fontSize: 11, fontWeight: '800' },
  orbitOne: { position: 'absolute', width: 140, height: 140, borderRadius: 70, borderWidth: 1, right: -17, top: 19 },
  orbitTwo: { position: 'absolute', width: 82, height: 82, borderRadius: 41, borderWidth: 1, right: 12, top: 48 },
  feedHeading: { gap: 12 },
  feedFilters: { gap: 8, paddingRight: 18 },
  posts: { gap: 13 },
  storageBanner: { borderRadius: 12, paddingHorizontal: 12, paddingVertical: 10 },
  storageText: { fontSize: 11, lineHeight: 16 },
  pressed: { opacity: 0.72 },
});
