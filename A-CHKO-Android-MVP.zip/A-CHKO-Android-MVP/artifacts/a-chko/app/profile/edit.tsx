import { Feather } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { useRouter } from 'expo-router';
import React, { useState } from 'react';
import { Alert, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { AppScreen, Avatar, IconButton, PrimaryButton, TopBar } from '@/components/primitives';
import { useAppState } from '@/context/app-state';
import type { AvatarTone } from '@/data/seed';
import { useColors } from '@/hooks/useColors';

const tones: AvatarTone[] = ['blue', 'coral', 'mint', 'gold', 'plum'];

export default function EditProfileScreen() {
  const colors = useColors();
  const router = useRouter();
  const { data, updateProfile } = useAppState();
  const [name, setName] = useState(data.profile.name);
  const [username, setUsername] = useState(data.profile.username.replace(/^@/, ''));
  const [bio, setBio] = useState(data.profile.bio);
  const [country, setCountry] = useState(data.profile.country);
  const [tone, setTone] = useState<AvatarTone>(data.profile.avatarTone);

  const save = () => {
    const safeName = name.trim();
    const safeUsername = username.trim().replace(/\s+/g, '').replace(/^@/, '');
    if (safeName.length < 2 || safeUsername.length < 3) {
      Alert.alert('Check your profile', 'Add a name and a username with at least three characters.');
      return;
    }
    updateProfile({
      name: safeName,
      username: `@${safeUsername}`,
      bio: bio.trim(),
      country: country.trim(),
      avatarTone: tone,
    });
    void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    router.back();
  };

  return (
    <AppScreen>
      <View style={styles.nav}>
        <IconButton icon="arrow-back" label="Go back" onPress={() => router.back()} />
        <TopBar title="Edit profile" />
      </View>
      <View style={styles.avatarArea}>
        <Avatar initials={name.split(/\s+/).map((part) => part[0] ?? '').join('').slice(0, 2).toUpperCase() || 'A'} tone={tone} size={80} />
        <Text style={[styles.avatarTitle, { color: colors.foreground }]}>Choose your profile color</Text>
        <View style={styles.tones}>
          {tones.map((item) => (
            <Pressable
              key={item}
              accessibilityRole="button"
              accessibilityLabel={`Choose ${item} profile color`}
              accessibilityState={{ selected: tone === item }}
              onPress={() => setTone(item)}
              style={({ pressed }) => [
                styles.toneButton,
                { borderColor: tone === item ? colors.foreground : colors.background, opacity: pressed ? 0.75 : 1 },
              ]}
            >
              <Avatar initials="" tone={item} size={29} />
            </Pressable>
          ))}
        </View>
      </View>
      <Field label="Name" value={name} onChangeText={setName} placeholder="Your name" maxLength={48} />
      <Field label="Username" value={username} onChangeText={setUsername} placeholder="username" maxLength={28} autoCapitalize="none" />
      <Field label="Bio" value={bio} onChangeText={setBio} placeholder="A little about you" maxLength={150} multiline />
      <Field label="Country or city" value={country} onChangeText={setCountry} placeholder="Optional" maxLength={60} />
      <Text style={[styles.note, { color: colors.mutedForeground }]}>
        Your profile is stored on this device in this MVP. It is not yet shared across accounts.
      </Text>
      <PrimaryButton label="Save profile" icon="check" onPress={save} testID="save-profile" />
    </AppScreen>
  );
}

function Field({
  label,
  value,
  onChangeText,
  placeholder,
  maxLength,
  multiline = false,
  autoCapitalize,
}: {
  label: string;
  value: string;
  onChangeText: (value: string) => void;
  placeholder: string;
  maxLength: number;
  multiline?: boolean;
  autoCapitalize?: 'none' | 'sentences' | 'words' | 'characters';
}) {
  const colors = useColors();
  return (
    <View style={styles.field}>
      <Text style={[styles.label, { color: colors.foreground }]}>{label}</Text>
      <TextInput
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        placeholderTextColor={colors.mutedForeground}
        maxLength={maxLength}
        multiline={multiline}
        autoCapitalize={autoCapitalize ?? 'sentences'}
        accessibilityLabel={label}
        style={[
          styles.input,
          { color: colors.foreground, backgroundColor: colors.card, borderColor: colors.border },
          multiline && styles.multiline,
        ]}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  nav: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  avatarArea: { alignItems: 'center', gap: 12, paddingVertical: 8 },
  avatarTitle: { fontSize: 12, fontWeight: '600' },
  tones: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  toneButton: { width: 37, height: 37, borderWidth: 2, borderRadius: 19, alignItems: 'center', justifyContent: 'center' },
  field: { gap: 7 },
  label: { fontSize: 12, fontWeight: '700' },
  input: { minHeight: 48, borderWidth: 1, borderRadius: 15, paddingHorizontal: 14, fontSize: 14 },
  multiline: { minHeight: 96, paddingVertical: 12, textAlignVertical: 'top' },
  note: { fontSize: 10, lineHeight: 15 },
});
