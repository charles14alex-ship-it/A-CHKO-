import { Ionicons } from '@expo/vector-icons';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { KeyboardAvoidingView } from 'react-native-keyboard-controller';
import React, { useMemo, useState } from 'react';
import {
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Avatar, IconButton, LoadingState, TopBar } from '@/components/primitives';
import { PostCard } from '@/components/post-card';
import { useAppState } from '@/context/app-state';
import { useColors } from '@/hooks/useColors';

export default function PostDetailScreen() {
  const colors = useColors();
  const router = useRouter();
  const { id } = useLocalSearchParams<{ id: string }>();
  const { data, isReady, addComment } = useAppState();
  const [draft, setDraft] = useState('');
  const post = useMemo(() => data.posts.find((item) => item.id === id), [data.posts, id]);

  if (!isReady) return <LoadingState />;

  const sendComment = () => {
    if (!draft.trim() || !post) return;
    addComment(post.id, draft);
    setDraft('');
  };

  return (
    <SafeAreaView edges={['top', 'bottom']} style={[styles.safeArea, { backgroundColor: colors.background }]}>
      <KeyboardAvoidingView
        behavior="padding"
        style={styles.flex}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : 0}
      >
        <View style={styles.page}>
          <View style={styles.nav}>
            <IconButton icon="arrow-back" label="Go back" onPress={() => router.back()} />
            <TopBar title="Conversation" />
          </View>
          {post ? (
            <>
              <ScrollView
                keyboardShouldPersistTaps="handled"
                showsVerticalScrollIndicator={false}
                contentContainerStyle={styles.scrollContent}
              >
                <PostCard post={post} />
                <View style={styles.commentsHeading}>
                  <Text style={[styles.commentsTitle, { color: colors.foreground }]}>Comments</Text>
                  <Text style={[styles.commentCount, { color: colors.mutedForeground }]}>{post.commentCount}</Text>
                </View>
                {post.comments.length ? (
                  post.comments.map((comment) => (
                    <View key={comment.id} style={styles.commentRow}>
                      <Avatar initials={comment.authorName.split(/\s+/).map((part) => part[0] ?? '').join('').slice(0, 2).toUpperCase()} tone={comment.avatarTone} size={36} />
                      <View style={[styles.commentBody, { backgroundColor: colors.card }]}>
                        <View style={styles.commentAuthorLine}>
                          <Text style={[styles.commentAuthor, { color: colors.foreground }]}>{comment.authorName}</Text>
                          <Text style={[styles.commentTime, { color: colors.mutedForeground }]}>{comment.createdAt}</Text>
                        </View>
                        <Text style={[styles.commentText, { color: colors.foreground }]}>{comment.body}</Text>
                      </View>
                    </View>
                  ))
                ) : (
                  <Text style={[styles.noComments, { color: colors.mutedForeground }]}>
                    Start the conversation with a helpful comment.
                  </Text>
                )}
              </ScrollView>
              <View style={[styles.composer, { borderTopColor: colors.border, backgroundColor: colors.background }]}>
                <TextInput
                  value={draft}
                  onChangeText={setDraft}
                  placeholder="Add a thoughtful comment…"
                  placeholderTextColor={colors.mutedForeground}
                  accessibilityLabel="Write a comment"
                  testID="comment-input"
                  returnKeyType="send"
                  onSubmitEditing={sendComment}
                  style={[styles.input, { color: colors.foreground, backgroundColor: colors.card, borderColor: colors.border }]}
                />
                <Pressable
                  accessibilityRole="button"
                  accessibilityLabel="Send comment"
                  onPress={sendComment}
                  disabled={!draft.trim()}
                  testID="send-comment"
                  style={({ pressed }) => [
                    styles.sendButton,
                    { backgroundColor: colors.primary, opacity: !draft.trim() ? 0.42 : pressed ? 0.76 : 1 },
                  ]}
                >
                  <Ionicons name="arrow-up" size={19} color={colors.primaryForeground} />
                </Pressable>
              </View>
            </>
          ) : (
            <View style={styles.notFound}>
              <Text style={[styles.notFoundTitle, { color: colors.foreground }]}>This post is unavailable</Text>
              <Text style={[styles.noComments, { color: colors.mutedForeground }]}>It may have been removed from this device.</Text>
            </View>
          )}
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1 },
  flex: { flex: 1 },
  page: { flex: 1, paddingHorizontal: 16 },
  nav: { flexDirection: 'row', alignItems: 'center', gap: 8, minHeight: 50 },
  scrollContent: { gap: 18, paddingTop: 8, paddingBottom: 18 },
  commentsHeading: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  commentsTitle: { fontSize: 17, fontWeight: '700' },
  commentCount: { fontSize: 12 },
  commentRow: { flexDirection: 'row', alignItems: 'flex-start', gap: 9 },
  commentBody: { flex: 1, borderRadius: 16, padding: 12, gap: 6 },
  commentAuthorLine: { flexDirection: 'row', alignItems: 'center', gap: 7 },
  commentAuthor: { fontSize: 12, fontWeight: '700' },
  commentTime: { fontSize: 10 },
  commentText: { fontSize: 12, lineHeight: 18 },
  noComments: { fontSize: 12, lineHeight: 18 },
  composer: { flexDirection: 'row', alignItems: 'center', gap: 9, borderTopWidth: StyleSheet.hairlineWidth, paddingTop: 11, paddingBottom: 5 },
  input: { flex: 1, minHeight: 44, borderRadius: 15, borderWidth: 1, paddingHorizontal: 14, fontSize: 13 },
  sendButton: { width: 42, height: 42, borderRadius: 15, alignItems: 'center', justifyContent: 'center' },
  notFound: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 8 },
  notFoundTitle: { fontSize: 17, fontWeight: '700' },
});
