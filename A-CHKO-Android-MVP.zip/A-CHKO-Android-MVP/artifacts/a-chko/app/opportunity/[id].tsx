import { Feather, Ionicons } from '@expo/vector-icons';
import { useLocalSearchParams, useRouter } from 'expo-router';
import React from 'react';
import { Alert, Image, Linking, Share, StyleSheet, Text, View } from 'react-native';
import { AppScreen, IconButton, PrimaryButton } from '@/components/primitives';
import { useAppState } from '@/context/app-state';
import { useColors } from '@/hooks/useColors';

const studentsImage = require('@/assets/images/students.jpg');

export default function OpportunityDetailScreen() {
  const colors = useColors();
  const router = useRouter();
  const { id } = useLocalSearchParams<{ id: string }>();
  const { data } = useAppState();
  const opportunity = data.opportunities.find((item) => item.id === id);

  if (!opportunity) {
    return (
      <AppScreen>
        <IconButton icon="arrow-back" label="Go back" onPress={() => router.back()} />
        <Text style={[styles.title, { color: colors.foreground }]}>Opportunity not found</Text>
        <Text style={[styles.body, { color: colors.mutedForeground }]}>This listing is no longer available.</Text>
      </AppScreen>
    );
  }

  const openSource = async () => {
    try {
      await Linking.openURL(opportunity.sourceUrl);
    } catch {
      Alert.alert('Could not open the source', 'Check your internet connection and try again.');
    }
  };

  return (
    <AppScreen>
      <View style={styles.nav}>
        <IconButton icon="arrow-back" label="Go back" onPress={() => router.back()} />
        <Text style={[styles.navTitle, { color: colors.foreground }]}>Opportunity</Text>
      </View>
      {opportunity.imageKey ? (
        <Image source={studentsImage} style={styles.heroImage} resizeMode="cover" />
      ) : null}
      <View style={[styles.categoryTag, { backgroundColor: colors.accent }]}>
        <Text style={[styles.categoryText, { color: colors.accentForeground }]}>{opportunity.category}</Text>
        <View style={[styles.dot, { backgroundColor: colors.mutedForeground }]} />
        <Text style={[styles.categoryText, { color: colors.mutedForeground }]}>Official directory</Text>
      </View>
      <Text style={[styles.title, { color: colors.foreground }]}>{opportunity.title}</Text>
      <Text style={[styles.organization, { color: colors.mutedForeground }]}>{opportunity.organization}</Text>
      <View style={[styles.metaCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <MetaLine icon="location-outline" label="Location" value={opportunity.location} />
        <View style={[styles.divider, { backgroundColor: colors.border }]} />
        <MetaLine icon="link-outline" label="Source" value={opportunity.sourceLabel} />
      </View>
      <View style={styles.section}>
        <Text style={[styles.sectionTitle, { color: colors.foreground }]}>About this opportunity</Text>
        <Text style={[styles.body, { color: colors.mutedForeground }]}>{opportunity.description}</Text>
      </View>
      <View style={styles.section}>
        <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Eligibility and deadlines</Text>
        <Text style={[styles.body, { color: colors.mutedForeground }]}>{opportunity.eligibility}</Text>
      </View>
      <View style={[styles.notice, { backgroundColor: colors.warningSurface }]}>
        <Feather name="info" size={16} color={colors.warning} />
        <Text style={[styles.noticeText, { color: colors.warning }]}>
          Requirements can change. Confirm every detail on the official source before applying.
        </Text>
      </View>
      <PrimaryButton label="Open official source" icon="external-link" onPress={() => void openSource()} testID="open-opportunity-source" />
      <IconButton
        icon="share-social-outline"
        label="Share opportunity"
        onPress={() => void Share.share({ message: `${opportunity.title} — ${opportunity.sourceUrl}` })}
      />
    </AppScreen>
  );
}

function MetaLine({ icon, label, value }: { icon: keyof typeof Ionicons.glyphMap; label: string; value: string }) {
  const colors = useColors();
  return (
    <View style={styles.metaLine}>
      <Ionicons name={icon} size={17} color={colors.brandBlue} />
      <View style={styles.metaCopy}>
        <Text style={[styles.metaLabel, { color: colors.mutedForeground }]}>{label}</Text>
        <Text style={[styles.metaValue, { color: colors.foreground }]}>{value}</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  nav: { flexDirection: 'row', alignItems: 'center', gap: 9, minHeight: 44 },
  navTitle: { fontSize: 16, fontWeight: '700' },
  heroImage: { width: '100%', height: 190, borderRadius: 22 },
  categoryTag: { alignSelf: 'flex-start', flexDirection: 'row', alignItems: 'center', gap: 8, paddingHorizontal: 11, paddingVertical: 7, borderRadius: 12 },
  categoryText: { fontSize: 10, fontWeight: '700' },
  dot: { width: 3, height: 3, borderRadius: 2 },
  title: { fontSize: 25, lineHeight: 31, letterSpacing: -0.65, fontWeight: '800' },
  organization: { fontSize: 13, marginTop: -12 },
  metaCard: { borderWidth: 1, borderRadius: 18, padding: 14, gap: 13 },
  metaLine: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  metaCopy: { flex: 1, gap: 2 },
  metaLabel: { fontSize: 10, fontWeight: '600' },
  metaValue: { fontSize: 12, fontWeight: '600' },
  divider: { height: StyleSheet.hairlineWidth, marginLeft: 27 },
  section: { gap: 6 },
  sectionTitle: { fontSize: 15, fontWeight: '700' },
  body: { fontSize: 13, lineHeight: 20 },
  notice: { flexDirection: 'row', alignItems: 'flex-start', gap: 9, padding: 13, borderRadius: 15 },
  noticeText: { flex: 1, fontSize: 11, lineHeight: 17 },
});
