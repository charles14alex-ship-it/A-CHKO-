import { Ionicons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { useRouter } from 'expo-router';
import React from 'react';
import {
  Alert,
  Image,
  Pressable,
  Share,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { useAppState } from '@/context/app-state';
import type { Post } from '@/data/seed';
import { useColors } from '@/hooks/useColors';
import { Avatar, formatCount, IconButton } from '@/components/primitives';

const creatorImage = require('@/assets/images/creator-story.jpg');
const studentsImage = require('@/assets/images/students.jpg');

export function PostCard({ post }: { post: Post }) {
  const colors = useColors();
  const router = useRouter();
  const {
    data,
    toggleLike,
    toggleSave,
    followCreator,
    joinCommunity,
    hidePost,
    blockCreator,
    reportPost,
  } = useAppState();
  const isFollowing = data.followingUsernames.includes(post.username);
  const isMember = post.communityId
    ? data.joinedCommunityIds.includes(post.communityId)
    : false;

  const showModeration = () => {
    Alert.alert('Post options', 'What would you like to do with this post?', [
      { text: 'Report post', onPress: () => reportPost(post.id) },
      { text: 'Hide this post', onPress: () => hidePost(post.id) },
      { text: 'Block creator', style: 'destructive', onPress: () => blockCreator(post.username) },
      { text: 'Cancel', style: 'cancel' },
    ]);
  };

  const sharePost = async () => {
    await Share.share({ message: `${post.body}\n\nShared from A-CHKO` });
  };

  const postImage =
    post.imageUri ??
    (post.imageKey === 'creatorStory'
      ? creatorImage
      : post.imageKey === 'students'
        ? studentsImage
        : undefined);

  return (
    <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
      <View style={styles.authorRow}>
        <Avatar initials={post.initials} tone={post.avatarTone} size={42} />
        <View style={styles.authorDetails}>
          <Text style={[styles.authorName, { color: colors.foreground }]}>{post.authorName}</Text>
          <Text style={[styles.authorMeta, { color: colors.mutedForeground }]}>
            {post.username} · {post.createdAt}
          </Text>
        </View>
        <IconButton icon="ellipsis-horizontal" label="Post options" onPress={showModeration} />
      </View>

      <Text style={[styles.postBody, { color: colors.foreground }]}>{post.body}</Text>

      {postImage ? (
        <Image
          accessibilityLabel={`Photo shared by ${post.authorName}`}
          source={typeof postImage === 'string' ? { uri: postImage } : postImage}
          resizeMode="cover"
          style={[styles.postImage, { backgroundColor: colors.muted }]}
        />
      ) : null}

      {post.communityName && post.communityId ? (
        <Pressable
          accessibilityRole="button"
          onPress={() => router.push(`/community/${post.communityId}`)}
          style={({ pressed }) => [styles.communityLink, pressed && styles.pressed]}
        >
          <Ionicons name="people-outline" size={14} color={colors.brandBlue} />
          <Text style={[styles.communityText, { color: colors.brandBlue }]}>{post.communityName}</Text>
          <Ionicons name="chevron-forward" size={13} color={colors.brandBlue} />
        </Pressable>
      ) : null}

      <View style={styles.engagementRow}>
        <Text style={[styles.engagementText, { color: colors.mutedForeground }]}>
          {formatCount(post.likes)} likes
        </Text>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="View comments"
          onPress={() => router.push(`/post/${post.id}`)}
          style={({ pressed }) => [styles.engagementButton, pressed && styles.pressed]}
        >
          <Text style={[styles.engagementText, { color: colors.mutedForeground }]}>
            {formatCount(post.commentCount)} comments
          </Text>
        </Pressable>
      </View>

      <View style={[styles.actionRow, { borderTopColor: colors.border }]}>
        <ActionButton
          icon={post.liked ? 'heart' : 'heart-outline'}
          label={post.liked ? 'Liked' : 'Like'}
          active={post.liked}
          onPress={() => {
            void Haptics.selectionAsync();
            toggleLike(post.id);
          }}
        />
        <ActionButton
          icon="chatbubble-ellipses-outline"
          label="Comment"
          onPress={() => router.push(`/post/${post.id}`)}
        />
        <ActionButton icon="share-outline" label="Share" onPress={() => void sharePost()} />
        <ActionButton
          icon={post.saved ? 'bookmark' : 'bookmark-outline'}
          label={post.saved ? 'Saved' : 'Save'}
          active={post.saved}
          onPress={() => {
            void Haptics.selectionAsync();
            toggleSave(post.id);
          }}
        />
      </View>

      <View style={styles.creatorActions}>
        <Pressable
          accessibilityRole="button"
          onPress={() => followCreator(post.username)}
          style={({ pressed }) => [
            styles.followButton,
            { backgroundColor: isFollowing ? colors.secondary : colors.foreground },
            pressed && styles.pressed,
          ]}
        >
          <Text style={[styles.followText, { color: isFollowing ? colors.foreground : colors.background }]}>
            {isFollowing ? 'Following creator' : 'Follow creator'}
          </Text>
        </Pressable>
        {post.communityId && post.communityName ? (
          <Pressable
            accessibilityRole="button"
            onPress={() => {
              if (!isMember) joinCommunity(post.communityId!);
              else router.push(`/community/${post.communityId}`);
            }}
            style={({ pressed }) => [
              styles.joinButton,
              { borderColor: colors.border },
              pressed && styles.pressed,
            ]}
          >
            <Ionicons name={isMember ? 'checkmark' : 'add'} size={16} color={colors.foreground} />
            <Text style={[styles.joinText, { color: colors.foreground }]}>
              {isMember ? 'Joined' : `Join ${post.communityName}`}
            </Text>
          </Pressable>
        ) : null}
      </View>
    </View>
  );
}

function ActionButton({
  icon,
  label,
  active = false,
  onPress,
}: {
  icon: keyof typeof Ionicons.glyphMap;
  label: string;
  active?: boolean;
  onPress: () => void;
}) {
  const colors = useColors();
  const tint = active ? colors.primary : colors.mutedForeground;
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={label}
      onPress={onPress}
      style={({ pressed }) => [styles.actionButton, pressed && styles.pressed]}
    >
      <Ionicons name={icon} size={19} color={tint} />
      <Text style={[styles.actionLabel, { color: tint }]}>{label}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: { borderWidth: 1, borderRadius: 23, padding: 15, gap: 13 },
  authorRow: { flexDirection: 'row', alignItems: 'center', gap: 11 },
  authorDetails: { flex: 1, gap: 3 },
  authorName: { fontSize: 14, fontWeight: '700' },
  authorMeta: { fontSize: 11 },
  postBody: { fontSize: 14, lineHeight: 21 },
  postImage: { width: '100%', height: 220, borderRadius: 17 },
  communityLink: { alignSelf: 'flex-start', flexDirection: 'row', alignItems: 'center', gap: 6, paddingVertical: 2 },
  communityText: { fontSize: 12, fontWeight: '700' },
  engagementRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  engagementButton: { paddingVertical: 3 },
  engagementText: { fontSize: 11, fontWeight: '500' },
  actionRow: { flexDirection: 'row', justifyContent: 'space-between', borderTopWidth: StyleSheet.hairlineWidth, paddingTop: 10 },
  actionButton: { minWidth: 55, flexDirection: 'row', alignItems: 'center', gap: 5 },
  actionLabel: { fontSize: 10, fontWeight: '600' },
  creatorActions: { flexDirection: 'row', alignItems: 'center', flexWrap: 'wrap', gap: 8 },
  followButton: { paddingHorizontal: 14, paddingVertical: 9, borderRadius: 14 },
  followText: { fontSize: 11, fontWeight: '700' },
  joinButton: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 10, paddingVertical: 8, borderWidth: 1, borderRadius: 13, flexShrink: 1 },
  joinText: { fontSize: 11, fontWeight: '600', flexShrink: 1 },
  pressed: { opacity: 0.7 },
});
