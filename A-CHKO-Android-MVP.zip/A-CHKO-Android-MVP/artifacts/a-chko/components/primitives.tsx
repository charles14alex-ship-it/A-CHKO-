import { Feather, Ionicons } from '@expo/vector-icons';
import React, { type ReactNode } from 'react';
import {
  ActivityIndicator,
  Image,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
  type StyleProp,
  type ViewStyle,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';
import type { AvatarTone } from '@/data/seed';

export function AppScreen({
  children,
  contentStyle,
}: {
  children: ReactNode;
  contentStyle?: StyleProp<ViewStyle>;
}) {
  const colors = useColors();
  return (
    <SafeAreaView edges={['top']} style={[styles.safeArea, { backgroundColor: colors.background }]}>
      <ScrollView
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
        contentContainerStyle={[
          styles.screenContent,
          { paddingTop: Platform.OS === 'web' ? 67 : 8, paddingBottom: Platform.OS === 'web' ? 120 : 112 },
          contentStyle,
        ]}
      >
        {children}
      </ScrollView>
    </SafeAreaView>
  );
}

export function BrandMark({ compact = false }: { compact?: boolean }) {
  const colors = useColors();
  return (
    <View style={styles.brandRow}>
      <Image
        source={require('../assets/images/icon.png')}
        style={styles.brandLogo}
        resizeMode="cover"
        accessibilityLabel="A-CHKO logo"
      />
      {!compact && (
        <View>
          <Text style={[styles.brandName, { color: colors.foreground }]}>A-CHKO</Text>
          <Text style={[styles.brandTagline, { color: colors.mutedForeground }]}>WATCH · CONNECT · DISCOVER</Text>
        </View>
      )}
    </View>
  );
}

export function TopBar({
  title,
  subtitle,
  right,
}: {
  title: string;
  subtitle?: string;
  right?: ReactNode;
}) {
  const colors = useColors();
  return (
    <View style={styles.topBar}>
      <View style={styles.topBarTitleGroup}>
        <Text style={[styles.topBarTitle, { color: colors.foreground }]}>{title}</Text>
        {subtitle ? <Text style={[styles.topBarSubtitle, { color: colors.mutedForeground }]}>{subtitle}</Text> : null}
      </View>
      {right ? <View style={styles.topBarRight}>{right}</View> : null}
    </View>
  );
}

export function Avatar({
  initials,
  tone = 'blue',
  size = 42,
}: {
  initials: string;
  tone?: AvatarTone;
  size?: number;
}) {
  const colors = useColors();
  const background = {
    blue: colors.avatarBlue,
    coral: colors.avatarCoral,
    mint: colors.avatarMint,
    gold: colors.avatarGold,
    plum: colors.avatarPlum,
  }[tone];
  return (
    <View
      style={[
        styles.avatar,
        { backgroundColor: background, width: size, height: size, borderRadius: size / 2 },
      ]}
      accessible
      accessibilityLabel={`${initials} profile picture`}
    >
      <Text style={[styles.avatarText, { color: colors.foreground, fontSize: size * 0.31 }]}>
        {initials}
      </Text>
    </View>
  );
}

export function IconButton({
  icon,
  label,
  onPress,
  size = 20,
  color,
  testID,
}: {
  icon: keyof typeof Ionicons.glyphMap;
  label: string;
  onPress: () => void;
  size?: number;
  color?: string;
  testID?: string;
}) {
  const colors = useColors();
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={label}
      onPress={onPress}
      testID={testID}
      hitSlop={10}
      style={({ pressed }) => [styles.iconButton, pressed && styles.pressed]}
    >
      <Ionicons name={icon} size={size} color={color ?? colors.foreground} />
    </Pressable>
  );
}

export function Pill({
  label,
  active = false,
  onPress,
  testID,
}: {
  label: string;
  active?: boolean;
  onPress: () => void;
  testID?: string;
}) {
  const colors = useColors();
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityState={{ selected: active }}
      onPress={onPress}
      testID={testID}
      style={({ pressed }) => [
        styles.pill,
        {
          backgroundColor: active ? colors.foreground : colors.card,
          borderColor: active ? colors.foreground : colors.border,
        },
        pressed && styles.pressed,
      ]}
    >
      <Text style={[styles.pillText, { color: active ? colors.background : colors.foreground }]}>{label}</Text>
    </Pressable>
  );
}

export function SectionHeading({
  title,
  action,
  onAction,
}: {
  title: string;
  action?: string;
  onAction?: () => void;
}) {
  const colors = useColors();
  return (
    <View style={styles.sectionHeading}>
      <Text style={[styles.sectionTitle, { color: colors.foreground }]}>{title}</Text>
      {action && onAction ? (
        <Pressable accessibilityRole="button" onPress={onAction} hitSlop={8}>
          <Text style={[styles.sectionAction, { color: colors.brandBlue }]}>{action}</Text>
        </Pressable>
      ) : null}
    </View>
  );
}

export function PrimaryButton({
  label,
  onPress,
  icon,
  disabled = false,
  testID,
}: {
  label: string;
  onPress: () => void;
  icon?: keyof typeof Feather.glyphMap;
  disabled?: boolean;
  testID?: string;
}) {
  const colors = useColors();
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityState={{ disabled }}
      disabled={disabled}
      onPress={onPress}
      testID={testID}
      style={({ pressed }) => [
        styles.primaryButton,
        { backgroundColor: colors.primary, opacity: disabled ? 0.45 : pressed ? 0.82 : 1 },
      ]}
    >
      {icon ? <Feather name={icon} size={16} color={colors.primaryForeground} /> : null}
      <Text style={[styles.primaryButtonText, { color: colors.primaryForeground }]}>{label}</Text>
    </Pressable>
  );
}

export function EmptyState({
  icon,
  title,
  description,
  action,
  onAction,
}: {
  icon: keyof typeof Feather.glyphMap;
  title: string;
  description: string;
  action?: string;
  onAction?: () => void;
}) {
  const colors = useColors();
  return (
    <View style={[styles.emptyState, { backgroundColor: colors.card, borderColor: colors.border }]}>
      <View style={[styles.emptyIcon, { backgroundColor: colors.accent }]}>
        <Feather name={icon} size={21} color={colors.accentForeground} />
      </View>
      <Text style={[styles.emptyTitle, { color: colors.foreground }]}>{title}</Text>
      <Text style={[styles.emptyDescription, { color: colors.mutedForeground }]}>{description}</Text>
      {action && onAction ? <PrimaryButton label={action} onPress={onAction} /> : null}
    </View>
  );
}

export function LoadingState() {
  const colors = useColors();
  return (
    <View style={styles.loading}>
      <ActivityIndicator color={colors.primary} />
    </View>
  );
}

export function formatCount(count: number) {
  if (count >= 1_000_000) return `${(count / 1_000_000).toFixed(1).replace('.0', '')}M`;
  if (count >= 1_000) return `${(count / 1_000).toFixed(1).replace('.0', '')}K`;
  return String(count);
}

const styles = StyleSheet.create({
  safeArea: { flex: 1 },
  screenContent: { paddingHorizontal: 18, gap: 20 },
  brandRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  brandLogo: { width: 38, height: 38, borderRadius: 13, overflow: 'hidden' },
  brandName: { fontSize: 19, fontWeight: '800', letterSpacing: 1.15 },
  brandTagline: { fontSize: 8, fontWeight: '700', letterSpacing: 1.1, marginTop: 1 },
  topBar: { minHeight: 48, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', gap: 12 },
  topBarTitleGroup: { flex: 1, gap: 2 },
  topBarTitle: { fontSize: 25, fontWeight: '700', letterSpacing: -0.6 },
  topBarSubtitle: { fontSize: 13, lineHeight: 18 },
  topBarRight: { flexDirection: 'row', alignItems: 'center', gap: 16 },
  avatar: { alignItems: 'center', justifyContent: 'center' },
  avatarText: { fontWeight: '800', letterSpacing: 0.2 },
  iconButton: { minWidth: 30, minHeight: 34, alignItems: 'center', justifyContent: 'center' },
  pressed: { opacity: 0.68, transform: [{ scale: 0.97 }] },
  pill: { minHeight: 36, borderRadius: 18, borderWidth: 1, paddingHorizontal: 15, alignItems: 'center', justifyContent: 'center' },
  pillText: { fontSize: 12, fontWeight: '600' },
  sectionHeading: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', gap: 12 },
  sectionTitle: { fontSize: 17, fontWeight: '700', letterSpacing: -0.2 },
  sectionAction: { fontSize: 13, fontWeight: '700' },
  primaryButton: { minHeight: 46, borderRadius: 15, paddingHorizontal: 18, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 9 },
  primaryButtonText: { fontSize: 14, fontWeight: '700' },
  emptyState: { alignItems: 'center', gap: 11, borderRadius: 22, borderWidth: 1, padding: 22 },
  emptyIcon: { width: 46, height: 46, borderRadius: 16, alignItems: 'center', justifyContent: 'center' },
  emptyTitle: { fontSize: 16, fontWeight: '700', textAlign: 'center' },
  emptyDescription: { fontSize: 13, lineHeight: 19, textAlign: 'center' },
  loading: { flex: 1, minHeight: 320, alignItems: 'center', justifyContent: 'center' },
});
