import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { useAppState } from '@/context/app-state';
import type { Community } from '@/data/seed';
import { useColors } from '@/hooks/useColors';
import { Avatar, formatCount } from '@/components/primitives';

export function CommunityCard({ community }: { community: Community }) {
  const colors = useColors();
  const router = useRouter();
  const { data, joinCommunity } = useAppState();
  const joined = data.joinedCommunityIds.includes(community.id);

  return (
    <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
      <Pressable
        accessibilityRole="button"
        accessibilityLabel={`Open ${community.name} community`}
        onPress={() => router.push(`/community/${community.id}`)}
        style={({ pressed }) => [styles.cardContent, pressed && styles.pressed]}
      >
        <Avatar initials={community.name.slice(0, 2).toUpperCase()} tone={community.avatarTone} size={48} />
        <View style={styles.info}>
          <Text style={[styles.name, { color: colors.foreground }]} numberOfLines={1}>{community.name}</Text>
          <Text style={[styles.meta, { color: colors.mutedForeground }]}>
            {formatCount(community.memberCount)} members · {community.category}
          </Text>
          <Text style={[styles.description, { color: colors.mutedForeground }]} numberOfLines={2}>
            {community.description}
          </Text>
        </View>
      </Pressable>
      <Pressable
        accessibilityRole="button"
        accessibilityLabel={joined ? `Leave ${community.name}` : `Join ${community.name}`}
        onPress={() => joinCommunity(community.id)}
        style={({ pressed }) => [
          styles.joinButton,
          {
            backgroundColor: joined ? colors.secondary : colors.foreground,
            opacity: pressed ? 0.72 : 1,
          },
        ]}
      >
        <Ionicons
          name={joined ? 'checkmark' : 'add'}
          size={17}
          color={joined ? colors.foreground : colors.background}
        />
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  card: { flexDirection: 'row', alignItems: 'center', gap: 12, padding: 14, borderRadius: 20, borderWidth: 1 },
  cardContent: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 12 },
  info: { flex: 1, gap: 4 },
  name: { fontSize: 14, fontWeight: '700' },
  meta: { fontSize: 10, fontWeight: '600' },
  description: { fontSize: 11, lineHeight: 16, marginTop: 2 },
  joinButton: { width: 34, height: 34, borderRadius: 13, alignItems: 'center', justifyContent: 'center' },
  pressed: { opacity: 0.75 },
});
