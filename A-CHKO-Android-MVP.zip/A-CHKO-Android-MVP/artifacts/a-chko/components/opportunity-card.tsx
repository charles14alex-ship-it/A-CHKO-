import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import React from 'react';
import { Image, Pressable, StyleSheet, Text, View } from 'react-native';
import type { Opportunity } from '@/data/seed';
import { useColors } from '@/hooks/useColors';

const studentsImage = require('@/assets/images/students.jpg');

export function OpportunityCard({ opportunity }: { opportunity: Opportunity }) {
  const colors = useColors();
  const router = useRouter();
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={`View ${opportunity.title}`}
      onPress={() => router.push(`/opportunity/${opportunity.id}`)}
      style={({ pressed }) => [
        styles.card,
        { backgroundColor: colors.card, borderColor: colors.border },
        pressed && styles.pressed,
      ]}
    >
      {opportunity.imageKey ? (
        <Image source={studentsImage} style={styles.image} resizeMode="cover" />
      ) : (
        <View style={[styles.imagePlaceholder, { backgroundColor: colors.accent }]}>
          <Ionicons name="briefcase-outline" size={22} color={colors.accentForeground} />
        </View>
      )}
      <View style={styles.content}>
        <View style={styles.labelRow}>
          <Text style={[styles.category, { color: colors.brandBlue }]}>{opportunity.category}</Text>
          <Text style={[styles.source, { color: colors.mutedForeground }]}>Official directory</Text>
        </View>
        <Text style={[styles.title, { color: colors.foreground }]} numberOfLines={2}>
          {opportunity.title}
        </Text>
        <Text style={[styles.organization, { color: colors.mutedForeground }]} numberOfLines={1}>
          {opportunity.organization}
        </Text>
        <View style={styles.locationRow}>
          <Ionicons name="location-outline" size={13} color={colors.mutedForeground} />
          <Text style={[styles.location, { color: colors.mutedForeground }]} numberOfLines={1}>
            {opportunity.location}
          </Text>
        </View>
      </View>
      <Ionicons name="open-outline" size={18} color={colors.mutedForeground} />
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: { flexDirection: 'row', alignItems: 'center', gap: 13, borderWidth: 1, borderRadius: 21, padding: 12 },
  image: { width: 72, height: 84, borderRadius: 14 },
  imagePlaceholder: { width: 72, height: 84, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  content: { flex: 1, gap: 5 },
  labelRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  category: { fontSize: 10, fontWeight: '800', textTransform: 'uppercase', letterSpacing: 0.7 },
  source: { fontSize: 9, fontWeight: '600' },
  title: { fontSize: 14, lineHeight: 19, fontWeight: '700' },
  organization: { fontSize: 11 },
  locationRow: { flexDirection: 'row', alignItems: 'center', gap: 3 },
  location: { fontSize: 10, flexShrink: 1 },
  pressed: { opacity: 0.72 },
});
