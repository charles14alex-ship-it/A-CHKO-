import AsyncStorage from '@react-native-async-storage/async-storage';
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from 'react';
import {
  INITIAL_APP_DATA,
  type AppData,
  type Comment,
  type Post,
  type Profile,
} from '@/data/seed';

const STORAGE_KEY = 'achko-local-state-v1';

type AppStateValue = {
  data: AppData;
  isReady: boolean;
  storageError: string | null;
  toggleLike: (postId: string) => void;
  toggleSave: (postId: string) => void;
  followCreator: (username: string) => void;
  joinCommunity: (communityId: string) => void;
  createPost: (body: string, imageUri?: string, communityId?: string) => void;
  addComment: (postId: string, body: string) => void;
  hidePost: (postId: string) => void;
  blockCreator: (username: string) => void;
  reportPost: (postId: string) => void;
  updateProfile: (profile: Partial<Profile>) => void;
};

const AppStateContext = createContext<AppStateValue | null>(null);

function makeId(prefix: string) {
  return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}

function mergeSeededCommunities(savedCommunities: AppData['communities'] | undefined) {
  const saved = savedCommunities ?? [];
  const savedById = new Map(saved.map((community) => [community.id, community] as const));
  const seededIds = new Set(INITIAL_APP_DATA.communities.map((community) => community.id));

  return [
    ...INITIAL_APP_DATA.communities.map((community) => savedById.get(community.id) ?? community),
    ...saved.filter((community) => !seededIds.has(community.id)),
  ];
}

export function AppStateProvider({ children }: { children: ReactNode }) {
  const [data, setData] = useState<AppData>(INITIAL_APP_DATA);
  const [isReady, setIsReady] = useState(false);
  const [storageError, setStorageError] = useState<string | null>(null);

  useEffect(() => {
    let isMounted = true;
    AsyncStorage.getItem(STORAGE_KEY)
      .then((stored) => {
        if (!isMounted) return;
        if (stored) {
          const savedData = JSON.parse(stored) as Partial<AppData>;
          setData({
            ...INITIAL_APP_DATA,
            ...savedData,
            communities: mergeSeededCommunities(savedData.communities),
          });
        }
        setIsReady(true);
      })
      .catch(() => {
        if (!isMounted) return;
        setStorageError('Your saved data could not be loaded. Changes may not persist on this device.');
        setIsReady(true);
      });
    return () => {
      isMounted = false;
    };
  }, []);

  useEffect(() => {
    if (!isReady || storageError) return;
    AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(data)).catch(() => {
      setStorageError('Your latest changes could not be saved on this device.');
    });
  }, [data, isReady, storageError]);

  const toggleLike = useCallback((postId: string) => {
    setData((current) => ({
      ...current,
      posts: current.posts.map((post) =>
        post.id === postId
          ? { ...post, liked: !post.liked, likes: post.likes + (post.liked ? -1 : 1) }
          : post,
      ),
    }));
  }, []);

  const toggleSave = useCallback((postId: string) => {
    setData((current) => ({
      ...current,
      posts: current.posts.map((post) =>
        post.id === postId ? { ...post, saved: !post.saved } : post,
      ),
    }));
  }, []);

  const followCreator = useCallback((username: string) => {
    setData((current) => ({
      ...current,
      followingUsernames: current.followingUsernames.includes(username)
        ? current.followingUsernames.filter((name) => name !== username)
        : [...current.followingUsernames, username],
    }));
  }, []);

  const joinCommunity = useCallback((communityId: string) => {
    setData((current) => ({
      ...current,
      joinedCommunityIds: current.joinedCommunityIds.includes(communityId)
        ? current.joinedCommunityIds.filter((id) => id !== communityId)
        : [...current.joinedCommunityIds, communityId],
    }));
  }, []);

  const createPost = useCallback((body: string, imageUri?: string, communityId?: string) => {
    setData((current) => {
      const community = current.communities.find((item) => item.id === communityId);
      const post: Post = {
        id: makeId('post'),
        authorName: current.profile.name,
        username: current.profile.username,
        initials: current.profile.name
          .split(/\s+/)
          .map((part) => part[0] ?? '')
          .join('')
          .slice(0, 2)
          .toUpperCase(),
        avatarTone: current.profile.avatarTone,
        createdAt: 'now',
        body: body.trim(),
        category: community?.category ?? 'Community',
        imageUri,
        communityId: community?.id,
        communityName: community?.name,
        likes: 0,
        liked: false,
        saved: false,
        comments: [],
        commentCount: 0,
      };
      return { ...current, posts: [post, ...current.posts] };
    });
  }, []);

  const addComment = useCallback((postId: string, body: string) => {
    const trimmedBody = body.trim();
    if (!trimmedBody) return;
    setData((current) => ({
      ...current,
      posts: current.posts.map((post) => {
        if (post.id !== postId) return post;
        const comment: Comment = {
          id: makeId('comment'),
          authorName: current.profile.name,
          username: current.profile.username,
          avatarTone: current.profile.avatarTone,
          body: trimmedBody,
          createdAt: 'now',
        };
        return {
          ...post,
          comments: [...post.comments, comment],
          commentCount: post.commentCount + 1,
        };
      }),
    }));
  }, []);

  const hidePost = useCallback((postId: string) => {
    setData((current) => ({
      ...current,
      hiddenPostIds: current.hiddenPostIds.includes(postId)
        ? current.hiddenPostIds
        : [...current.hiddenPostIds, postId],
    }));
  }, []);

  const blockCreator = useCallback((username: string) => {
    setData((current) => ({
      ...current,
      blockedUsernames: current.blockedUsernames.includes(username)
        ? current.blockedUsernames
        : [...current.blockedUsernames, username],
      followingUsernames: current.followingUsernames.filter((name) => name !== username),
    }));
  }, []);

  const reportPost = useCallback((postId: string) => {
    setData((current) => ({
      ...current,
      reportedPostIds: current.reportedPostIds.includes(postId)
        ? current.reportedPostIds
        : [...current.reportedPostIds, postId],
      hiddenPostIds: current.hiddenPostIds.includes(postId)
        ? current.hiddenPostIds
        : [...current.hiddenPostIds, postId],
    }));
  }, []);

  const updateProfile = useCallback((profile: Partial<Profile>) => {
    setData((current) => {
      const previousUsername = current.profile.username;
      const nextProfile = { ...current.profile, ...profile };
      const initials = nextProfile.name
        .split(/\s+/)
        .map((part) => part[0] ?? '')
        .join('')
        .slice(0, 2)
        .toUpperCase();
      return {
        ...current,
        profile: nextProfile,
        posts: current.posts.map((post) =>
          post.username === previousUsername
            ? { ...post, authorName: nextProfile.name, username: nextProfile.username, initials, avatarTone: nextProfile.avatarTone }
            : {
                ...post,
                comments: post.comments.map((comment) =>
                  comment.username === previousUsername
                    ? { ...comment, authorName: nextProfile.name, username: nextProfile.username, avatarTone: nextProfile.avatarTone }
                    : comment,
                ),
              },
        ),
      };
    });
  }, []);

  const value = useMemo(
    () => ({
      data,
      isReady,
      storageError,
      toggleLike,
      toggleSave,
      followCreator,
      joinCommunity,
      createPost,
      addComment,
      hidePost,
      blockCreator,
      reportPost,
      updateProfile,
    }),
    [
      data,
      isReady,
      storageError,
      toggleLike,
      toggleSave,
      followCreator,
      joinCommunity,
      createPost,
      addComment,
      hidePost,
      blockCreator,
      reportPost,
      updateProfile,
    ],
  );

  return <AppStateContext.Provider value={value}>{children}</AppStateContext.Provider>;
}

export function useAppState() {
  const context = useContext(AppStateContext);
  if (!context) {
    throw new Error('useAppState must be used within AppStateProvider');
  }
  return context;
}
