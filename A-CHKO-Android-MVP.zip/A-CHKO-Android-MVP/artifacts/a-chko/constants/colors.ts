/**
 * Semantic design tokens for the mobile app.
 *
 * These tokens mirror the naming conventions used in web artifacts (index.css)
 * so that multi-artifact projects share a cohesive visual identity.
 *
 * Replace the placeholder values below with values that match the project's
 * brand. If a sibling web artifact exists, read its index.css and convert the
 * HSL values to hex so both artifacts use the same palette.
 *
 * To add dark mode, add a `dark` key with the same token names.
 * The useColors() hook will automatically pick it up.
 */

const colors = {
  light: {
    text: '#171B27',
    tint: '#E95F4B',
    background: '#F7F5F1',
    foreground: '#171B27',
    card: '#FFFFFF',
    cardForeground: '#171B27',
    primary: '#E95F4B',
    primaryForeground: '#FFFFFF',
    secondary: '#ECEEF3',
    secondaryForeground: '#202638',
    muted: '#EFEEE9',
    mutedForeground: '#737988',
    accent: '#E9EFFA',
    accentForeground: '#2858A9',
    destructive: '#C83939',
    destructiveForeground: '#FFFFFF',
    border: '#E5E2DC',
    input: '#E5E2DC',
    brandWarm: '#F36D53',
    brandBlue: '#5B91F1',
    brandMint: '#83CBAF',
    brandGold: '#E5B967',
    brandPlum: '#B99EDC',
    avatarBlue: '#BBD2FA',
    avatarCoral: '#F4B4A7',
    avatarMint: '#B8E0CE',
    avatarGold: '#F0D49F',
    avatarPlum: '#D1C0EA',
    heroBackground: '#11192B',
    heroForeground: '#F8F6F1',
    heroMuted: '#C4CCDA',
    heroAccent: '#365A9D',
    heroOrbit: 'rgba(219, 230, 255, 0.2)',
    warning: '#965912',
    warningSurface: '#FFF1D9',
    statusBar: 'dark' as const,
  },
  dark: {
    text: '#F4F2ED',
    tint: '#FF806C',
    background: '#0D1422',
    foreground: '#F4F2ED',
    card: '#151F30',
    cardForeground: '#F4F2ED',
    primary: '#FF806C',
    primaryForeground: '#241116',
    secondary: '#222D40',
    secondaryForeground: '#F4F2ED',
    muted: '#1A2638',
    mutedForeground: '#A4ADC0',
    accent: '#1C304B',
    accentForeground: '#B7D2FF',
    destructive: '#FF7777',
    destructiveForeground: '#241116',
    border: '#29364A',
    input: '#29364A',
    brandWarm: '#F36D53',
    brandBlue: '#79A8FF',
    brandMint: '#89D3B5',
    brandGold: '#F0CA7D',
    brandPlum: '#C3A8EA',
    avatarBlue: '#3C5379',
    avatarCoral: '#754D50',
    avatarMint: '#345E53',
    avatarGold: '#706044',
    avatarPlum: '#5A4D73',
    heroBackground: '#11192B',
    heroForeground: '#F8F6F1',
    heroMuted: '#C4CCDA',
    heroAccent: '#365A9D',
    heroOrbit: 'rgba(219, 230, 255, 0.2)',
    warning: '#E2B66D',
    warningSurface: '#3B2D1C',
    statusBar: 'light' as const,
  },
  radius: 8,
};

export default colors;
