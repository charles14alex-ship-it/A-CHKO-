# A-CHKO — Watch · Connect · Discover

## Director's treatment

- **Promise:** A-CHKO brings creator stories, communities, and opportunities into one social experience.
- **Audience:** People looking for content to watch, people to connect with, and practical next steps to discover.
- **Format and runtime:** 9:16 vertical, 26.0 seconds, looping, no voiceover.
- **Identity:** Use the mobile app's palette: warm paper `#F7F5F1`, deep navy `#11192B`, coral `#F36D53` / `#E95F4B`, blue `#5B91F1`, mint `#83CBAF`, and gold `#E5B967`. Space Grotesk headlines; DM Sans support copy. Use the existing A-CHKO app-mark image and wordmark text, not a replacement logo.
- **Hero:** The actual A-CHKO feed screenshot, followed by creator and student photography from the app's existing asset library.
- **Motion:** Phone-screen macro-to-wide reframing, ring/node geometry that changes function between shots, and clean split/aperture transitions carrying one coral ring between scenes.
- **Arc:** Human hook → watch → connect → discover → resolved A-CHKO lockup. Quick opening, varied mid-film pacing, deliberate readable ending.
- **Payoff:** The app-mark's coral circle expands from the end-card into the creator image at the opening, making the loop a motivated graphic match.
- **Sound intent:** One upbeat, modern instrumental bed with warm electronic percussion and a restrained melodic lift near the discovery/end-card handoff. No lyrics or voiceover. Musical alignment is unverified until the track is generated and listened to.

## Timeline

| Time | Focus | Main movement | Composition | Handoff |
| --- | --- | --- | --- | --- |
| 00.00–04.50 | A creator and the world around her | Image lands immediately; words punch in; a coral ring tightens into an aperture | Full-bleed human image, high/low type zones | Aperture opens into the real feed screen |
| 04.50–09.50 | Watch | Feed screen pushes into its creator-story photo | Tall, lightly angled phone frame on warm paper | Coral ring leaves the screen edge and becomes a people-network hub |
| 09.50–14.30 | Connect | Three portraits resolve; lines trace between community nodes | Centered, square photo panel within a tall navy stage | A connecting line becomes a route into opportunity cards |
| 14.30–19.50 | Discover | Three resource cards arrive one at a time; the route links them | Asymmetric editorial layout with a right-side photo crop | Cards fold into the coral aperture |
| 19.50–26.00 | Brand close | Three words punch; app mark and wordmark resolve; aperture opens back to the creator | Quiet centered end card, distinct from every prior image-led shot | Aperture matches the opening image/ring |

## Shot-by-shot script

### Shot 01 — “YOUR WORLD” / 00.00–04.50 / 4.50s

- **Purpose:** Establish that A-CHKO is human and content-led, then promise a broader social destination without claiming outcomes.
- **Exact content and holds:** `YOUR` at 00.12; `WORLD` at 00.48; `in motion.` at 01.18; then the single words `Stories.` at 02.05, `People.` at 02.58, and `Possibilities.` at 03.11. All are fully readable before the next replaces them. No other copy.
- **Composition:** Open directly on the creator-story photograph, full-width and nearly full-height, with a navy veil at the top and bottom for contrast. Keep the creator's face in the central upper third and her phone in the lower-left third. Put the headline in the upper safe zone and the changing single-word line in the lower safe zone. A thin coral ring sits behind the type at 20% opacity; never cover the face.
- **Artistic idea:** The photograph's real phone becomes an implied portal: a mask aligned to its screen expands into the aperture carrying the next shot.
- **Timed choreography:** 00.00 image is already visible; a 180ms camera settle prevents a blank opening. 00.12–00.44 `YOUR` snaps in from a clipped vertical mask; 00.48–00.85 `WORLD` punches 1.12x then settles. 00.95–01.25 camera pushes toward the creator's phone. 01.18–01.75 `in motion.` reveals below the headline. 02.05, 02.58, and 03.11 replace one lower word each with 180ms overlap. 03.55 the coral ring contracts around the phone; 04.05–04.50 it opens to the next shot as the photograph pulls back.
- **Transition contract:** Match the ring's center and diameter to the phone-screen aperture at Shot 02's first frame. The phone's rectangular edge shears away as the real app screenshot resolves; combine aperture expansion with the image-scale pullback.
- **Assets and technique:** Existing `creator-story.jpg`; generated app mark as small lower-corner brand stamp only if it remains legible; masked typography and a lightweight SVG ring. No generated imagery.
- **Sound intent:** Instrumental begins on the first image; three short percussive accents support the three word changes. Exact beat placement awaits the music track.

### Shot 02 — “WATCH” / 04.50–09.50 / 5.00s

- **Purpose:** Show the A-CHKO feed as an actual product surface and make creator content the main event.
- **Exact content and holds:** `WATCH` at 04.72–08.95; `Stories worth stopping for.` at 06.35–08.80. Feed text visible inside the screenshot is original app UI, not new promotional copy.
- **Composition:** The actual 402×874 A-CHKO feed capture fills a rounded, narrow phone frame approximately 86% of the canvas width and 82% of its height. The frame starts just left of center, tilted -3° on warm paper. Large navy `WATCH` sits behind it in the top quarter, partially cropped but readable. Do not redraw the captured interface or place promotional copy over its text.
- **Artistic idea:** A real interface is treated as a window, not a flat slide: the visible creator photo grows to the frame edge while the phone bezel recedes.
- **Timed choreography:** 04.50 ring is already centered on the matching aperture. 04.55–05.15 screenshot resolves from a close, softly blurred screen crop into the complete phone, while `WATCH` is already visible as an outline. 05.25–05.75 phone settles to 0°; the ring slips from the screen's upper-right corner. 06.05–06.45 the viewport pushes into the feed photo inside the screenshot. 06.35–06.85 the support line reveals beneath the image, never covering it. 07.10–08.00 the photo holds large enough to read as creator content. 08.10–08.80 the frame rotates 2° toward portrait, and the coral ring exits toward the middle of the following student photograph. 08.80–09.50 the content photo cross-matches to the next shot as ring and split-panel close.
- **Transition contract:** The creator-photo crop gives way to the student photograph on the same scale and screen position. The coral ring lands as the next scene's network hub; use that object match plus a two-panel split reveal.
- **Assets and technique:** Existing A-CHKO feed screenshot copied from the app preview; existing `creator-story.jpg` is visible inside the screenshot. CSS phone frame, perspective, restrained blur only on the moving frame edge.
- **Sound intent:** Maintain the groove; the phone settling and photo push are intended to land on a downbeat, pending audio check.

### Shot 03 — “CONNECT” / 09.50–14.30 / 4.80s

- **Purpose:** Communicate communities and peer connection through an inclusive real-world image and one simple network graphic.
- **Exact content and holds:** `CONNECT` at 09.72–12.25; `Find your people.` at 12.52–14.05. Four abstract colored nodes contain no names or invented user claims.
- **Composition:** Deep navy field. A near-square photo panel, 86% of canvas width, sits centered slightly below mid-frame so all three students remain visible. `CONNECT` occupies the upper safe zone. Four small nodes sit around the photo perimeter, each in a different A-CHKO accent color. Keep connection paths outside faces and text.
- **Artistic idea:** The coral ring becomes a shared meeting point: its outline divides into a path that reaches the three students and surrounding nodes.
- **Timed choreography:** 09.50 the photo is already present at 0.92 scale; ring arrives at its top edge. 09.72–10.15 `CONNECT` expands through a vertical mask. 10.20–11.05 three nodes pop one at a time at 0.42s spacing using a stiff spring, then a fourth settles near the frame edge. 11.10–11.85 SVG paths trace from the ring to the nodes in sequence. 12.05–12.45 the camera pulls back to reveal the whole group photograph. 12.52–13.05 `Find your people.` rises into the lower safe zone. 13.10–13.70 each node responds with one restrained pulse. 13.75–14.30 the connected path straightens into a vertical route line and the photo panel shifts right.
- **Transition contract:** The route line exits from the lower-center node and enters at the same screen coordinate in Shot 04. Pair the route draw with a vertical split that reveals the opportunity layout.
- **Assets and technique:** Existing `students.jpg`; SVG stroked paths, four fixed-position colored dots, no random particles. Photo appears once in this scene.
- **Sound intent:** A light rhythmic lift for each node; exact timing awaits the track.

### Shot 04 — “DISCOVER” / 14.30–19.50 / 5.20s

- **Purpose:** Show the Opportunity Hub as a place to find official starting points for scholarships and careers, without implying that listings guarantee eligibility or outcomes.
- **Exact content and holds:** `DISCOVER` at 14.50–16.75; cards arrive with `Scholarships` at 15.45–18.85, `Careers` at 16.35–18.85, and `Creative opportunities` at 17.25–18.85. A small supporting label on each card reads `Official directories` only for the scholarship and career cards; the creative card reads `Explore the hub`. `A place to start.` appears 18.05–19.05.
- **Composition:** Warm paper background. An asymmetrically cropped slice of `students.jpg` occupies the right 52% from mid-height to the bottom; the left column is navy typography. Three compact cream/navy cards fan over the lower-right image edge. The coral route enters from the top-left and travels behind, never over, card text. Card copy stays in the center 80% of frame height.
- **Artistic idea:** One path becomes three distinct next-step cards, so a community connection literally branches into opportunities.
- **Timed choreography:** 14.30 the vertical route line continues from Shot 03 while a vertical paper panel unfolds. 14.50–15.10 `DISCOVER` clips open. At 15.35, 16.25, and 17.15, one card at a time flips 3D from the route line, lands with slight rotation, then squares to camera. At 17.75 the route traces behind all three cards. 18.05–18.40 `A place to start.` appears in the lower-left safe zone. 18.65–19.20 the cards fold inward toward their shared coral point while the photo crop contracts. 19.20–19.50 that point becomes a circular opening onto the warm end-card.
- **Transition contract:** The three cards converge into a single coral circle; a circular aperture plus brief headline shear reveals Shot 05. Do not hold an empty paper field.
- **Assets and technique:** Existing `students.jpg`, used for a second and final time with a materially different right-side crop; typographic cards, CSS 3D with shallow rotation, one SVG path.
- **Sound intent:** Build gently across the staggered cards, then resolve the musical lift as the aperture opens. Alignment is unverified until the generated music is reviewed.

### Shot 05 — Brand close / 19.50–26.00 / 6.50s

- **Purpose:** Leave a clear brand and the complete product promise; end with an intentional loop rather than another feature shot.
- **Exact content and holds:** `WATCH` at 19.68–20.15, `CONNECT` at 20.12–20.62, `DISCOVER` at 20.58–21.08. The app-mark image and `A-CHKO` wordmark resolve at 21.15–22.00. The tagline `WATCH · CONNECT · DISCOVER` appears at 22.05–24.72 and remains readable. No call-to-action button.
- **Composition:** Quiet warm-paper field. Center the existing app mark at 30vmin, wordmark below at 13vmin, and tagline at 4.2vmin. Use deep navy type; a coral disc and thin blue orbit sit behind the mark. Keep logo and type within a 10% inset.
- **Artistic idea:** The three promise words orbit and compress into the authentic app mark; then its coral disc becomes the aperture for the film's opening creator photograph.
- **Timed choreography:** 19.50 circle is already open. 19.68–21.08 the three words punch through a stable center stage, one at a time with 0.4s gaps. 21.15–21.75 the existing icon resolves from the coral disc at 0.78 scale and settles; `A-CHKO` locks on below by 22.00. 22.05–22.45 the tagline tracks open, then holds clearly through 24.72. 24.75–26.00 the icon's coral disc grows to 3.2x, its plane fades before any heavy scaling, and the creator photograph reveals through the expanding circular mask; at 26.00 the resulting crop and coral ring match Shot 01's opening composition.
- **Transition contract:** Closing circle, opening circle, photo crop, and ring align in position and scale. The outgoing logo resolves toward the opener's ring while the incoming photograph is already visible; use a clip-path reveal plus small scale-through, never a blank cut.
- **Assets and technique:** Existing A-CHKO icon image; wordmark set in Space Grotesk; CSS clip-path and one coral ring. Do not recreate or recolor the mark.
- **Sound intent:** Musical lift resolves on the logo; the last 1.25s of music should support the aperture loop without a separate sound effect. Beat match remains unverified until audio playback.

## Pre-code review

- All five shots use distinct compositions: full-bleed photo, framed product screen, centered group photo/network, asymmetric editorial opportunity layout, and quiet brand lockup.
- Every shot has a visual change at least once per second; the opener changes every 0.5s or faster. The final 20% is a motivated image-and-aperture handoff, not a dead hold.
- The coral ring/route is the continuity carrier. The type, photographs, screen, network, cards, and final mark each have separate zones.
- All stills and the app icon already exist in the A-CHKO project. No fabricated listings, endorsements, metrics, or user identities are introduced.
