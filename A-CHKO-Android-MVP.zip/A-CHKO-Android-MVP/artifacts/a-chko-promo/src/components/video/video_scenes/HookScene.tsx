import { AnimatePresence, motion } from 'framer-motion';
import { useState } from 'react';

import { useSceneTimer } from '@/lib/video';

const WORDS = ['Stories.', 'People.', 'Possibilities.'];
const IMAGE = `${import.meta.env.BASE_URL}images/creator-story.jpg`;

export function HookScene() {
  const [wordIndex, setWordIndex] = useState(-1);

  useSceneTimer([
    { time: 2050, callback: () => setWordIndex(0) },
    { time: 2580, callback: () => setWordIndex(1) },
    { time: 3110, callback: () => setWordIndex(2) },
  ]);

  return (
    <motion.section
      className="film-scene hook-scene"
      initial={false}
      animate={{ clipPath: 'inset(0% 0% 0% 0%)' }}
      exit={{
        clipPath: 'circle(0% at 20% 20%)',
        transition: { duration: 0.48, ease: [0.76, 0, 0.24, 1] },
      }}
    >
      <motion.img
        className="hook-photo"
        src={IMAGE}
        alt=""
        initial={{ scale: 1.13 }}
        animate={{ scale: 1.03 }}
        transition={{ duration: 4.4, ease: 'linear' }}
      />
      <div className="hook-vignette" />
      <div className="hook-copy">
        <p className="hook-kicker">A-CHKO · YOUR WORLD</p>
        <h1 className="hook-title">
          <motion.span
            initial={{ y: '115%', opacity: 0.9 }}
            animate={{ y: '0%', opacity: 1 }}
            transition={{ duration: 0.36, ease: [0.18, 0.88, 0.28, 1] }}
          >
            YOUR
          </motion.span>
          <motion.span
            initial={{ y: '115%', opacity: 0.9 }}
            animate={{ y: '0%', opacity: 1 }}
            transition={{ duration: 0.42, delay: 0.29, ease: [0.18, 0.88, 0.28, 1] }}
          >
            WORLD
          </motion.span>
        </h1>
        <motion.p
          className="hook-subtitle"
          initial={{ clipPath: 'inset(0 100% 0 0)', opacity: 0.75 }}
          animate={{ clipPath: 'inset(0 0 0 0)', opacity: 1 }}
          transition={{ duration: 0.48, delay: 0.86, ease: [0.22, 1, 0.36, 1] }}
        >
          in motion.
        </motion.p>
        <div className="hook-word-stage" aria-live="off">
          <AnimatePresence mode="sync" initial={false}>
            {wordIndex >= 0 && (
              <motion.p
                className="hook-word"
                key={wordIndex}
                initial={{ y: '90%', opacity: 0, scale: 0.94 }}
                animate={{ y: '0%', opacity: 1, scale: 1 }}
                exit={{ y: '-45%', opacity: 0, scale: 1.04, transition: { duration: 0.16 } }}
                transition={{ type: 'spring', stiffness: 390, damping: 28 }}
              >
                {WORDS[wordIndex]}
              </motion.p>
            )}
          </AnimatePresence>
        </div>
      </div>
      <motion.div
        className="hook-screen-aperture"
        initial={{ scale: 0.58, opacity: 0.4 }}
        animate={{ scale: [0.58, 0.58, 1.22], opacity: [0.4, 0.62, 0] }}
        transition={{ duration: 4.35, times: [0, 0.8, 1], ease: 'easeInOut' }}
        aria-hidden="true"
      />
    </motion.section>
  );
}
