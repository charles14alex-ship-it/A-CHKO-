import { AnimatePresence, motion } from 'framer-motion';
import { useState } from 'react';

import { useSceneTimer } from '@/lib/video';

const MARK = `${import.meta.env.BASE_URL}images/achko-icon.png`;
const CREATOR = `${import.meta.env.BASE_URL}images/creator-story.jpg`;
const WORDS = ['WATCH', 'CONNECT', 'DISCOVER'];

export function FinaleScene() {
  const [phase, setPhase] = useState(0);
  const [loopReveal, setLoopReveal] = useState(false);

  useSceneTimer([
    { time: 620, callback: () => setPhase(1) },
    { time: 1050, callback: () => setPhase(2) },
    { time: 1520, callback: () => setPhase(3) },
    { time: 5200, callback: () => setLoopReveal(true) },
  ]);

  return (
    <motion.section
      className={`film-scene finale-scene ${loopReveal ? 'finale-loop-reveal' : ''}`}
      initial={false}
      animate={{ clipPath: 'inset(0% 0% 0% 0%)' }}
      exit={{ opacity: 1 }}
    >
      <motion.img
        className="finale-loop-photo"
        src={CREATOR}
        alt=""
        animate={{
          clipPath: loopReveal ? 'circle(100% at 50% 52%)' : 'circle(0% at 50% 52%)',
          scale: loopReveal ? 1.03 : 1.08,
        }}
        transition={{ duration: 1.22, ease: [0.72, 0, 0.18, 1] }}
      />
      <motion.div
        className="finale-loop-aperture"
        animate={{
          clipPath: loopReveal ? 'circle(100% at 50% 52%)' : 'circle(0% at 50% 52%)',
          opacity: loopReveal ? 1 : 0,
        }}
        transition={{ duration: 1.22, ease: [0.72, 0, 0.18, 1] }}
      />
      <motion.div
        className="finale-lockup"
        animate={{
          opacity: loopReveal ? 0 : phase === 3 ? 1 : 0,
          scale: loopReveal ? 0.82 : 1,
        }}
        transition={{ duration: loopReveal ? 0.5 : 0.34, ease: [0.22, 1, 0.36, 1] }}
      >
        <motion.div
          className="finale-mark-wrap"
          initial={{ scale: 0.72, rotate: -8 }}
          animate={{ scale: phase === 3 ? 1 : 0.72, rotate: 0 }}
          transition={{ type: 'spring', stiffness: 260, damping: 23 }}
        >
          <img src={MARK} alt="" />
        </motion.div>
        <motion.p
          className="finale-brand-name"
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: phase === 3 ? 0 : 20, opacity: phase === 3 ? 1 : 0 }}
          transition={{ duration: 0.4, delay: 0.06, ease: [0.22, 1, 0.36, 1] }}
        >
          A-CHKO
        </motion.p>
        <motion.p
          className="finale-tagline"
          initial={{ letterSpacing: '0.02em', opacity: 0 }}
          animate={{
            letterSpacing: phase === 3 ? '0.17em' : '0.02em',
            opacity: phase === 3 ? 1 : 0,
          }}
          transition={{ duration: 0.5, delay: 0.2, ease: [0.22, 1, 0.36, 1] }}
        >
          WATCH · CONNECT · DISCOVER
        </motion.p>
      </motion.div>
      <div className="finale-word-stage">
        <AnimatePresence mode="sync" initial={false}>
          {phase < 3 && (
            <motion.h2
              className="finale-word"
              key={phase}
              initial={{ scale: 1.42, y: 16, opacity: 0, filter: 'blur(5px)' }}
              animate={{ scale: 1, y: 0, opacity: 1, filter: 'blur(0px)' }}
              exit={{ scale: 0.82, y: -16, opacity: 0, transition: { duration: 0.14 } }}
              transition={{ duration: 0.34, ease: [0.22, 1, 0.36, 1] }}
            >
              {WORDS[phase]}
            </motion.h2>
          )}
        </AnimatePresence>
      </div>
    </motion.section>
  );
}
