import { motion } from 'framer-motion';
import { useState } from 'react';

import { useSceneTimer } from '@/lib/video';

const APP_PREVIEW = `${import.meta.env.BASE_URL}images/app-preview.jpg`;
const GLINT_EASE = [0.22, 1, 0.36, 1] as const;

export function WatchScene() {
  const [closeup, setCloseup] = useState(false);
  useSceneTimer([
    { time: 1550, callback: () => setCloseup(true) },
    { time: 3400, callback: () => setCloseup(false) },
  ]);

  return (
    <motion.section
      className="film-scene watch-scene"
      initial={false}
      animate={{ clipPath: 'inset(0% 0% 0% 0%)' }}
      exit={{
        clipPath: 'inset(48% 0% 48% 0%)',
        transition: { duration: 0.44, ease: [0.76, 0, 0.24, 1] },
      }}
    >
      <motion.h2
        className="watch-backword"
        initial={{ scale: 0.86, opacity: 0.08 }}
        animate={{ scale: 1, opacity: 0.14 }}
        transition={{ duration: 1.1, ease: [0.22, 1, 0.36, 1] }}
      >
        WATCH
      </motion.h2>
      <motion.div
        className="watch-phone"
        initial={{ scale: 0.94, y: 58, rotate: -2.4 }}
        animate={{ scale: 1, y: 0, rotate: -0.7 }}
        transition={{ duration: 0.82, ease: [0.2, 0.92, 0.28, 1] }}
      >
        <div className="watch-phone-glass">
          <motion.img
            className="watch-product-image"
            src={APP_PREVIEW}
            alt="A-CHKO home feed preview"
            animate={{ scale: closeup ? 1.17 : 1, y: closeup ? '-1.7%' : '0%' }}
            transition={{ duration: closeup ? 0.86 : 0.72, ease: GLINT_EASE }}
          />
        </div>
        <motion.div
          className="watch-phone-glint"
          initial={{ x: '-45%', opacity: 0 }}
          animate={{ x: '460%', opacity: [0, 0.82, 0] }}
          transition={{ duration: 1.15, delay: 2.15, times: [0, 0.48, 1], ease: 'easeInOut' }}
          aria-hidden="true"
        />
      </motion.div>
      <motion.p
        className="watch-caption"
        initial={{ y: 24, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.48, delay: 1.85, ease: GLINT_EASE }}
      >
        Stories worth stopping for.
      </motion.p>
      <motion.div
        className="watch-scanline"
        initial={{ scaleX: 0, opacity: 0 }}
        animate={{ scaleX: [0, 1, 1], opacity: [0, 0.65, 0] }}
        transition={{ duration: 1.1, delay: 2.1, times: [0, 0.28, 1], ease: 'easeOut' }}
        aria-hidden="true"
      />
    </motion.section>
  );
}
