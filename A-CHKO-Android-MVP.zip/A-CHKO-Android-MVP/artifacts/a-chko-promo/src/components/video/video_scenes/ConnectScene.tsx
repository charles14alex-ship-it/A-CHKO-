import { motion } from 'framer-motion';

const STUDENTS = `${import.meta.env.BASE_URL}images/students.jpg`;
const NODES = [
  { className: 'node-a', color: 'var(--color-primary)', delay: 0.4 },
  { className: 'node-b', color: 'var(--color-accent)', delay: 0.82 },
  { className: 'node-c', color: 'var(--color-mint)', delay: 1.24 },
  { className: 'node-d', color: 'var(--color-gold)', delay: 1.66 },
];

export function ConnectScene() {
  return (
    <motion.section
      className="film-scene connect-scene"
      initial={false}
      animate={{ clipPath: 'inset(0% 0% 0% 0%)' }}
      exit={{
        clipPath: 'inset(100% 0% 0% 0%)',
        transition: { duration: 0.48, ease: [0.76, 0, 0.24, 1] },
      }}
    >
      <div className="connect-topline">
        <span className="connect-index">02 / 03</span>
        <span className="connect-rule" />
      </div>
      <motion.h2
        className="connect-title"
        initial={{ y: 30, opacity: 0.25 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
      >
        CONNECT
      </motion.h2>
      <svg className="connect-lines" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true">
        <motion.path
          d="M 8 29 C 22 30, 27 39, 39 45 C 51 51, 66 48, 92 41"
          initial={{ pathLength: 0, opacity: 0 }}
          animate={{ pathLength: 1, opacity: 0.8 }}
          transition={{ duration: 0.92, delay: 0.84, ease: 'easeInOut' }}
        />
        <motion.path
          d="M 9 72 C 24 68, 32 58, 44 52 C 60 44, 71 59, 91 66"
          initial={{ pathLength: 0, opacity: 0 }}
          animate={{ pathLength: 1, opacity: 0.62 }}
          transition={{ duration: 0.82, delay: 1.24, ease: 'easeInOut' }}
        />
      </svg>
      <motion.div
        className="connect-photo-frame"
        initial={{ scale: 0.91, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        transition={{ duration: 0.82, ease: [0.22, 1, 0.36, 1] }}
      >
        <img src={STUDENTS} alt="Students sharing a moment on campus" />
      </motion.div>
      {NODES.map((node) => (
        <motion.div
          className={`connect-node ${node.className}`}
          key={node.className}
          style={{ backgroundColor: node.color }}
          initial={{ scale: 0.16, opacity: 0 }}
          animate={{ scale: [0.16, 1.13, 1], opacity: 1 }}
          transition={{
            type: 'spring',
            stiffness: 420,
            damping: 24,
            delay: node.delay,
          }}
          aria-hidden="true"
        />
      ))}
      <motion.p
        className="connect-caption"
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.45, delay: 2.9, ease: [0.22, 1, 0.36, 1] }}
      >
        Find your people.
      </motion.p>
    </motion.section>
  );
}
