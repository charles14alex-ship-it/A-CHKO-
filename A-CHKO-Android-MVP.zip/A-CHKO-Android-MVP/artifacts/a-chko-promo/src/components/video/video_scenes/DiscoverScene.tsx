import { motion } from 'framer-motion';
import { useState } from 'react';

import { useSceneTimer } from '@/lib/video';

const STUDENTS = `${import.meta.env.BASE_URL}images/students.jpg`;
const OPPORTUNITIES = [
  {
    number: '01',
    title: 'Scholarships',
    detail: 'Official directories',
    tone: 'opportunity-coral',
  },
  {
    number: '02',
    title: 'Careers',
    detail: 'Official directories',
    tone: 'opportunity-blue',
  },
  {
    number: '03',
    title: 'Creative opportunities',
    detail: 'Explore the hub',
    tone: 'opportunity-gold',
  },
];

export function DiscoverScene() {
  const [closing, setClosing] = useState(false);
  useSceneTimer([{ time: 4350, callback: () => setClosing(true) }]);

  return (
    <motion.section
      className={`film-scene discover-scene ${closing ? 'discover-closing' : ''}`}
      initial={false}
      animate={{ clipPath: 'inset(0% 0% 0% 0%)' }}
      exit={{
        clipPath: 'circle(0% at 48% 54%)',
        transition: { duration: 0.45, ease: [0.76, 0, 0.24, 1] },
      }}
    >
      <motion.div
        className="discover-photo"
        initial={{ scale: 1.08, x: 28 }}
        animate={closing ? { scale: 0.78, x: 24, opacity: 0.3 } : { scale: 1, x: 0, opacity: 1 }}
        transition={{ duration: 1.05, ease: [0.22, 1, 0.36, 1] }}
      >
        <img src={STUDENTS} alt="" />
      </motion.div>
      <div className="discover-photo-wash" />
      <div className="discover-header">
        <span className="discover-eyebrow">03 / 03 · OPPORTUNITY HUB</span>
        <motion.h2
          className="discover-title"
          initial={{ clipPath: 'inset(0 100% 0 0)' }}
          animate={{ clipPath: 'inset(0 0 0 0)' }}
          transition={{ duration: 0.58, ease: [0.22, 1, 0.36, 1] }}
        >
          DISCOVER
        </motion.h2>
      </div>
      <motion.div
        className="discover-route"
        initial={{ scaleY: 0 }}
        animate={{ scaleY: 1 }}
        transition={{ duration: 0.92, delay: 0.55, ease: [0.22, 1, 0.36, 1] }}
        aria-hidden="true"
      />
      <div className="opportunity-stack">
        {OPPORTUNITIES.map((item, index) => (
          <motion.div
            className={`opportunity-card ${item.tone}`}
            key={item.number}
            initial={{ x: -38, y: 18, rotate: -6, opacity: 0 }}
            animate={closing
              ? { x: 78, y: 86, rotate: 14, scale: 0.14, opacity: 0 }
              : { x: 0, y: 0, rotate: index === 1 ? 1.2 : -1.2, scale: 1, opacity: 1 }}
            transition={{
              duration: closing ? 0.55 : 0.5,
              delay: closing ? index * 0.035 : 0.95 + index * 0.79,
              ease: [0.18, 0.88, 0.28, 1],
            }}
          >
            <span className="opportunity-number">{item.number}</span>
            <span className="opportunity-copy">
              <strong>{item.title}</strong>
              <small>{item.detail}</small>
            </span>
            <span className="opportunity-mark" aria-hidden="true" />
          </motion.div>
        ))}
      </div>
      <motion.p
        className="discover-caption"
        initial={{ y: 18, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.42, delay: 3.9, ease: [0.22, 1, 0.36, 1] }}
      >
        A place to start.
      </motion.p>
    </motion.section>
  );
}
