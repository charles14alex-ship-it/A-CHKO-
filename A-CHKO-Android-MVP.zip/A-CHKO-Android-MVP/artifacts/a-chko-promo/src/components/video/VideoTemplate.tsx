import {
  VideoCanvas,
  type VideoAspectRatio,
  useVideoPlayer,
} from '@/lib/video';
import { AnimatePresence, motion } from 'framer-motion';
import type { ComponentType } from 'react';

import { ConnectScene } from './video_scenes/ConnectScene';
import { DiscoverScene } from './video_scenes/DiscoverScene';
import { FinaleScene } from './video_scenes/FinaleScene';
import { HookScene } from './video_scenes/HookScene';
import { WatchScene } from './video_scenes/WatchScene';
import './video_scenes/achko-film.css';

export const SCENE_DURATIONS = {
  hook: 4500,
  watch: 5000,
  connect: 4800,
  discover: 5200,
  finale: 6500,
} as const;

const VIDEO_ASPECT_RATIO: VideoAspectRatio = '9:16';
const SCENE_COMPONENTS: ComponentType[] = [
  HookScene,
  WatchScene,
  ConnectScene,
  DiscoverScene,
  FinaleScene,
];
const FIELD_COLORS = [
  'var(--color-bg-dark)',
  'var(--color-bg-light)',
  'var(--color-bg-dark)',
  'var(--color-bg-light)',
  'var(--color-bg-light)',
];
const ORBIT_POSES = [
  { left: '18%', top: '17%', size: '25vmin', rotate: 0, opacity: 0.42 },
  { left: '83%', top: '15%', size: '27vmin', rotate: 44, opacity: 0.32 },
  { left: '14%', top: '55%', size: '34vmin', rotate: 95, opacity: 0.48 },
  { left: '85%', top: '72%', size: '29vmin', rotate: 152, opacity: 0.38 },
  { left: '18%', top: '17%', size: '25vmin', rotate: 0, opacity: 0.42 },
];

export default function VideoTemplate() {
  const { currentScene } = useVideoPlayer({
    durations: SCENE_DURATIONS,
  });
  const SceneComponent = SCENE_COMPONENTS[currentScene];

  return (
    <VideoCanvas
      aspectRatio={VIDEO_ASPECT_RATIO}
      className="achko-video-canvas"
      style={{ backgroundColor: 'var(--color-bg-dark)' }}
    >
      <motion.div
        className="film-field"
        initial={false}
        animate={{ backgroundColor: FIELD_COLORS[currentScene] }}
        transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
      />
      <AnimatePresence mode="sync" initial={false}>
        {SceneComponent && <SceneComponent key={currentScene} />}
      </AnimatePresence>
      <motion.div
        className="brand-orbit-anchor"
        initial={false}
        animate={{
          left: ORBIT_POSES[currentScene].left,
          top: ORBIT_POSES[currentScene].top,
          opacity: ORBIT_POSES[currentScene].opacity,
        }}
        transition={{ duration: 0.78, ease: [0.22, 1, 0.36, 1] }}
        aria-hidden="true"
      >
        <motion.svg
          className="brand-orbit"
          viewBox="0 0 120 120"
          animate={{
            width: ORBIT_POSES[currentScene].size,
            height: ORBIT_POSES[currentScene].size,
            rotate: ORBIT_POSES[currentScene].rotate,
          }}
          transition={{ duration: 0.78, ease: [0.22, 1, 0.36, 1] }}
        >
          <circle cx="60" cy="60" r="54" pathLength="1" />
          <circle className="brand-orbit-core" cx="60" cy="60" r="4" />
        </motion.svg>
      </motion.div>
    </VideoCanvas>
  );
}
