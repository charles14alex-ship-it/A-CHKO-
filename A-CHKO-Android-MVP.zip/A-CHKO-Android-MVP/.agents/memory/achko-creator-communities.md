---
name: A-CHKO creator communities
description: Product purpose for A-CHKO's regional and international creator groups.
---

A-CHKO's communities should include American, European, Asian and international creator groups. They are for musicians, actors and other talented people to find sponsors, competitions and other opportunities.

**Why:** The user described this as a core purpose of the Communities area.

**How to apply:** Shape creator group discovery and posting around portfolios, sponsor leads, auditions, competitions and opportunities. Do not describe a sponsor or listing as verified unless a verification process exists.
