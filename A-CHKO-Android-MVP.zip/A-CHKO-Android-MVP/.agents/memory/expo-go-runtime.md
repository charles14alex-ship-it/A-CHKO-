---
name: Expo Go runtime
description: Replit Expo workflow behavior when the native React Native DevTools helper cannot load.
---

Expo may log a React Native DevTools installation error because `libglib-2.0.so.0` is unavailable in the runtime. Metro can still start and print a working Expo Go QR code; this DevTools-only error does not by itself mean the app failed to launch.

**Why:** Replit's managed workflow successfully served this Expo Go app despite the missing shared library.

**How to apply:** If the same error appears, check for Metro startup and the Expo Go QR code before changing dependencies or treating it as an app crash.

Expo's compatibility checker may also request a fresh SDK patch that the package registry's minimum-release-age gate has not admitted yet. `expo install --fix` can then fail with `ERR_PNPM_NO_MATURE_MATCHING_VERSION`.

**Why:** The Expo patch was published only shortly before the check, and the registry blocked it by policy.

**How to apply:** Do not disable the package age gate. Keep the currently installed versions, report the exact compatibility warning, and retry once the package is eligible.
